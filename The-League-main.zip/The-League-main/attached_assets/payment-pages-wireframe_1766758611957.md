# Payment Pages Wireframe
## `/payment/success` & `/payment/cancel` - Registration Completion

---

## Page Overview

**Purpose:** 
- Confirm successful registration and payment
- Handle failed/cancelled payments
- Provide clear next steps
- Capture important post-payment actions

**URL Patterns:** 
- `/payment/success?session_id={stripe_session_id}`
- `/payment/cancel?session_id={stripe_session_id}`

**Context:**
- User returns from Stripe Checkout
- Session contains league/tournament registration details
- Payment status determines which page displays

**Key Actions:**
- View registration confirmation
- Add event to calendar
- Share registration
- Access league/tournament details
- Retry payment (cancel page)
- Contact support

---

## Payment Success Page

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Logo] The League     [Search]  [Discover] [My Leagues] [Profile]║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │                    SUCCESS HEADER                           │  ║
║ │                                                             │  ║
║ │                         ✅                                   │  ║
║ │                    [Check mark icon]                        │  ║
║ │                    Large, animated                          │  ║
║ │                                                             │  ║
║ │                  Registration Confirmed!                     │  ║
║ │                  ━━━━━━━━━━━━━━━━━━━━━                      │  ║
║ │                                                             │  ║
║ │           You're all set for Monday Night Golf League       │  ║
║ │                                                             │  ║
║ │  Confirmation sent to alex@example.com                      │  ║
║ │  Order #MNG-2025-0142                                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📋 REGISTRATION DETAILS                                    │  ║
║ │                                                             │  ║
║ │  League: Monday Night Golf League                           │  ║
║ │  Venue: Desert Ridge Golf Club                              │  ║
║ │  Start Date: Monday, February 3, 2025                       │  ║
║ │  Time: 5:30 PM                                              │  ║
║ │  Format: Individual Stroke Play • 18 holes                  │  ║
║ │  Duration: 12 weeks + playoffs                              │  ║
║ │                                                             │  ║
║ │  Your Information:                                          │  ║
║ │  Name: Alex Martinez                                        │  ║
║ │  Email: alex@example.com                                    │  ║
║ │  Phone: (555) 123-4567                                     │  ║
║ │  GHIN: 1234567                                              │  ║
║ │  Handicap: 8.2                                              │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💳 PAYMENT SUMMARY                                         │  ║
║ │                                                             │  ║
║ │  Registration Fee                           $450.00         │  ║
║ │  Early Bird Discount                        -$50.00         │  ║
║ │  Processing Fee                             $  0.00         │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Total Paid                                 $400.00         │  ║
║ │                                                             │  ║
║ │  Payment Method: •••• 4242                                  │  ║
║ │  Transaction ID: ch_3Abc123XYZ456                          │  ║
║ │  Date: December 26, 2024 at 2:34 PM                        │  ║
║ │                                                             │  ║
║ │  [Download Receipt] [Email Receipt]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🎯 WHAT'S NEXT?                                            │  ║
║ │                                                             │  ║
║ │  1️⃣ Check Your Email                                        │  ║
║ │     We've sent you a confirmation with all the details,    │  ║
║ │     league rules, and a waiver to sign.                     │  ║
║ │                                                             │  ║
║ │  2️⃣ Add to Calendar                                         │  ║
║ │     Don't miss any league nights! Add all 12 weeks to      │  ║
║ │     your calendar.                                          │  ║
║ │     [Add to Google Calendar] [Download .ics]               │  ║
║ │                                                             │  ║
║ │  3️⃣ Flight Assignment                                       │  ║
║ │     You'll be assigned to a flight based on your handicap  │  ║
║ │     2 days before the first round (Feb 1). You'll receive  │  ║
║ │     an email with your flight and pairings.                 │  ║
║ │                                                             │  ║
║ │  4️⃣ First League Night                                      │  ║
║ │     Monday, February 3, 2025 at 5:30 PM                    │  ║
║ │     Desert Ridge Golf Club - Championship Course            │  ║
║ │     Arrive 15 minutes early for check-in                    │  ║
║ │     [Get Directions]                                        │  ║
║ │                                                             │  ║
║ │  5️⃣ Join the League Chat                                    │  ║
║ │     Connect with other players, ask questions, and get     │  ║
║ │     updates from the organizer.                             │  ║
║ │     [Join League Chat]                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📱 DOWNLOAD THE APP                                        │  ║
║ │                                                             │  ║
║ │  Get the most out of your league experience:                │  ║
║ │  • Live scoring and standings                               │  ║
║ │  • Push notifications for schedule changes                  │  ║
║ │  • Chat with league members                                 │  ║
║ │  • Track your stats and progress                            │  ║
║ │                                                             │  ║
║ │  [Download on App Store] [Get it on Google Play]           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🤝 IMPORTANT INFORMATION                                   │  ║
║ │                                                             │  ║
║ │  League Rules & Format:                                     │  ║
║ │  • Review the complete league rules (emailed to you)       │  ║
║ │  • Sign the waiver before first round                       │  ║
║ │  • Familiarize yourself with scoring format                 │  ║
║ │                                                             │  ║
║ │  Cancellation Policy:                                       │  ║
║ │  • Full refund available until January 20, 2025            │  ║
║ │  • 50% refund until February 1, 2025                       │  ║
║ │  • No refunds after season starts                           │  ║
║ │  [View Cancellation Policy]                                 │  ║
║ │                                                             │  ║
║ │  Need to Cancel?                                            │  ║
║ │  [Request Cancellation]                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🎉 SHARE YOUR EXCITEMENT                                   │  ║
║ │                                                             │  ║
║ │  Tell your friends you're playing in Monday Night Golf!    │  ║
║ │                                                             │  ║
║ │  [Share on Twitter] [Share on Facebook] [Copy Link]        │  ║
║ │                                                             │  ║
║ │  Invite friends to join:                                    │  ║
║ │  "Hey! I just registered for Monday Night Golf League at   │  ║
║ │  Desert Ridge. Only 3 spots left - join me!"               │  ║
║ │  [Send Invitation]                                          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  QUICK ACTIONS                                              │  ║
║ │                                                             │  ║
║ │  ┌────────────────────┐  ┌────────────────────┐            │  ║
║ │  │ View League Details│  │ Browse More Leagues│            │  ║
║ │  └────────────────────┘  └────────────────────┘            │  ║
║ │                                                             │  ║
║ │  ┌────────────────────┐  ┌────────────────────┐            │  ║
║ │  │ Go to Dashboard    │  │ Contact Organizer  │            │  ║
║ │  └────────────────────┘  └────────────────────┘            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💬 NEED HELP?                                              │  ║
║ │                                                             │  ║
║ │  Questions about your registration?                         │  ║
║ │                                                             │  ║
║ │  📧 Email: support@theleague.com                            │  ║
║ │  📞 Phone: (555) 123-4567                                   │  ║
║ │  💬 Live Chat: [Start Chat]                                │  ║
║ │                                                             │  ║
║ │  [Visit Help Center]                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Payment Cancel/Failed Page

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Logo] The League     [Search]  [Discover] [My Leagues] [Profile]║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │                    CANCEL HEADER                            │  ║
║ │                                                             │  ║
║ │                         ⚠️                                   │  ║
║ │                  [Warning icon]                             │  ║
║ │                                                             │  ║
║ │                  Payment Not Completed                       │  ║
║ │                  ━━━━━━━━━━━━━━━━━━━━━                      │  ║
║ │                                                             │  ║
║ │        Your registration for Monday Night Golf League       │  ║
║ │                    was not completed                         │  ║
║ │                                                             │  ║
║ │  Don't worry - your spot is still available for 15 minutes  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  ❌ WHAT HAPPENED?                                          │  ║
║ │                                                             │  ║
║ │  Your payment was not processed. This could be because:     │  ║
║ │  • You clicked "Back" or "Cancel" during checkout          │  ║
║ │  • Your card was declined                                   │  ║
║ │  • The payment session timed out                            │  ║
║ │  • There was a temporary connection issue                   │  ║
║ │                                                             │  ║
║ │  Your registration is not complete and you are not yet     │  ║
║ │  enrolled in the league.                                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💡 WHAT YOU CAN DO                                         │  ║
║ │                                                             │  ║
║ │  1️⃣ Try Again                                               │  ║
║ │     Your spot is held for 15 minutes. Complete your        │  ║
║ │     registration now to secure your place.                  │  ║
║ │                                                             │  ║
║ │     ⏱️ Time remaining: 14:32                                │  ║
║ │     [Complete Registration Now - $450]                      │  ║
║ │                                                             │  ║
║ │  2️⃣ Use a Different Payment Method                          │  ║
║ │     If your card was declined, try:                         │  ║
║ │     • A different credit/debit card                         │  ║
║ │     • Checking with your bank about the charge             │  ║
║ │     • Ensuring you have sufficient funds                    │  ║
║ │                                                             │  ║
║ │  3️⃣ Contact Your Bank                                       │  ║
║ │     Some banks block online payments for security.          │  ║
║ │     Call your bank to authorize the transaction.            │  ║
║ │                                                             │  ║
║ │  4️⃣ Save for Later                                          │  ║
║ │     Not ready to complete now? We'll save your information │  ║
║ │     and send you a reminder to finish registration.         │  ║
║ │     [Save & Finish Later]                                   │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📋 YOUR REGISTRATION DETAILS                               │  ║
║ │                                                             │  ║
║ │  League: Monday Night Golf League                           │  ║
║ │  Venue: Desert Ridge Golf Club                              │  ║
║ │  Start Date: Monday, February 3, 2025                       │  ║
║ │  Amount: $450.00 (Early Bird: $400.00)                     │  ║
║ │                                                             │  ║
║ │  Your Information:                                          │  ║
║ │  Name: Alex Martinez                                        │  ║
║ │  Email: alex@example.com                                    │  ║
║ │  Handicap: 8.2                                              │  ║
║ │                                                             │  ║
║ │  All your information is saved - just complete payment!     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  ⏰ EARLY BIRD REMINDER                                     │  ║
║ │                                                             │  ║
║ │  🔥 Early bird pricing ($400) ends January 15!              │  ║
║ │                                                             │  ║
║ │  Complete your registration now to save $50!                │  ║
║ │  Regular price after Jan 15: $450                           │  ║
║ │                                                             │  ║
║ │  Days remaining: 20 days                                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🎯 SPOTS FILLING FAST                                      │  ║
║ │                                                             │  ║
║ │  Only 4 spots remaining in this league!                     │  ║
║ │                                                             │  ║
║ │  28/32 players registered                                   │  ║
║ │  ████████████████████████████░░░░ 88%                       │  ║
║ │                                                             │  ║
║ │  Don't miss out - complete your registration now.           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  PRIMARY ACTION                                             │  ║
║ │                                                             │  ║
║ │  ┌──────────────────────────────────────────────────────┐  │  ║
║ │  │                                                      │  │  ║
║ │  │  [Complete My Registration - $450]                   │  │  ║
║ │  │                                                      │  │  ║
║ │  │  Large, prominent button                             │  │  ║
║ │  │  Green/blue color, centered                          │  │  ║
║ │  │                                                      │  │  ║
║ │  └──────────────────────────────────────────────────────┘  │  ║
║ │                                                             │  ║
║ │  🔒 Secure payment powered by Stripe                       │  ║
║ │  💳 All major credit cards accepted                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  OTHER OPTIONS                                              │  ║
║ │                                                             │  ║
║ │  Not ready to complete registration?                        │  ║
║ │                                                             │  ║
║ │  [Browse Other Leagues] [View League Details]              │  ║
║ │  [Return to Home] [Contact Support]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💬 NEED HELP?                                              │  ║
║ │                                                             │  ║
║ │  Having trouble with payment?                               │  ║
║ │                                                             │  ║
║ │  Common issues & solutions:                                 │  ║
║ │  • Card declined → Contact your bank                       │  ║
║ │  • Payment timing out → Check internet connection          │  ║
║ │  • Zip code not matching → Verify billing address          │  ║
║ │  • CVV error → Check 3-digit code on card back             │  ║
║ │                                                             │  ║
║ │  Still having issues?                                       │  ║
║ │  📧 Email: support@theleague.com                            │  ║
║ │  📞 Phone: (555) 123-4567                                   │  ║
║ │  💬 Live Chat: [Start Chat]                                │  ║
║ │                                                             │  ║
║ │  We're here to help you complete your registration!         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Tournament Registration Success Variant

```
╔═══════════════════════════════════════════════════════════════════╗
║  ✅ TOURNAMENT REGISTRATION CONFIRMED!                            ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  You're all set for Spring Championship                           ║
║  Team: The Birdies                                                ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 TOURNAMENT DETAILS                                      │  ║
║ │                                                             │  ║
║ │  Event: Spring Championship                                 │  ║
║ │  Date: Saturday, March 15, 2025                             │  ║
║ │  Time: 7:00 AM (Shotgun Start)                             │  ║
║ │  Venue: Desert Ridge Golf Club - Championship Course        │  ║
║ │  Format: 4-Person Scramble                                  │  ║
║ │                                                             │  ║
║ │  Team Registration #SC-2025-0024                            │  ║
║ │                                                             │  ║
║ │  Team Captain: Alex Martinez                                │  ║
║ │  Team Members:                                              │  ║
║ │  • Sarah Chen (Hdcp 9.5)                                    │  ║
║ │  • John Martinez (Hdcp 7.8)                                 │  ║
║ │  • Lisa Anderson (Hdcp 10.1)                                │  ║
║ │                                                             │  ║
║ │  Team Average Handicap: 8.9                                 │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💳 PAYMENT SUMMARY                                         │  ║
║ │                                                             │  ║
║ │  Team Entry Fee (4 players)                 $500.00         │  ║
║ │  Early Bird Discount                        -$50.00         │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Total Paid                                 $450.00         │  ║
║ │                                                             │  ║
║ │  Per Player: $112.50                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📅 TOURNAMENT DAY SCHEDULE                                 │  ║
║ │                                                             │  ║
║ │  Saturday, March 15, 2025                                   │  ║
║ │                                                             │  ║
║ │  6:00 AM - Check-in opens                                   │  ║
║ │  6:30 AM - Breakfast service                                │  ║
║ │  6:45 AM - Rules meeting & team photos                      │  ║
║ │  7:00 AM - SHOTGUN START                                    │  ║
║ │  12:00 PM - Lunch & awards ceremony                         │  ║
║ │                                                             │  ║
║ │  [Add to Calendar] [Get Directions]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🎯 NEXT STEPS FOR YOUR TEAM                                │  ║
║ │                                                             │  ║
║ │  1️⃣ Notify Team Members                                     │  ║
║ │     Email confirmations sent to all team members            │  ║
║ │     Share the tournament details and schedule               │  ║
║ │                                                             │  ║
║ │  2️⃣ Sign Waivers                                            │  ║
║ │     All team members must sign waivers by March 10          │  ║
║ │     Link sent to each player's email                        │  ║
║ │                                                             │  ║
║ │  3️⃣ Review Tournament Rules                                 │  ║
║ │     Familiarize your team with format and rules             │  ║
║ │     [View Tournament Rules]                                 │  ║
║ │                                                             │  ║
║ │  4️⃣ Hole Assignment                                         │  ║
║ │     You'll receive your starting hole 2 days before         │  ║
║ │     (March 13) via email                                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 PRIZE POOL                                              │  ║
║ │                                                             │  ║
║ │  Total Prize Pool: $5,000                                   │  ║
║ │                                                             │  ║
║ │  🥇 1st Place: $2,000                                       │  ║
║ │  🥈 2nd Place: $1,200                                       │  ║
║ │  🥉 3rd Place: $800                                         │  ║
║ │     4th Place: $500                                         │  ║
║ │     5th Place: $300                                         │  ║
║ │  Plus contest prizes (closest to pin, longest drive)        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Individual Player Registration Success

```
╔═══════════════════════════════════════════════════════════════════╗
║  ✅ REGISTRATION CONFIRMED!                                       ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  You're registered as an individual player                        ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  👥 TEAM MATCHING                                           │  ║
║ │                                                             │  ║
║ │  We'll match you with other individual players to form a    │  ║
║ │  complete team of 4.                                        │  ║
║ │                                                             │  ║
║ │  What happens next:                                         │  ║
║ │  • You'll receive team assignment by March 1                │  ║
║ │  • Matched based on skill level and availability            │  ║
║ │  • Introduced to teammates via email                        │  ║
║ │  • Group chat created for coordination                      │  ║
║ │                                                             │  ║
║ │  Your Profile:                                              │  ║
║ │  Handicap: 8.2                                              │  ║
║ │  Preferred Days: Weekday evenings, Weekend mornings         │  ║
║ │  Experience: 3 years playing                                │  ║
║ │                                                             │  ║
║ │  💡 Want to form your own team instead?                     │  ║
║ │  Invite 3 friends and we'll create your team!               │  ║
║ │  [Invite Friends to Form Team]                              │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Mobile Optimization

### Mobile Success Page (Condensed)
```
┌───────────────────────────────┐
│           ✅                   │
│  Registration Confirmed!      │
│                               │
│  Monday Night Golf League     │
│  Desert Ridge Golf Club       │
│                               │
│  Order #MNG-2025-0142         │
│  Total Paid: $400.00          │
│                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                               │
│  What's Next:                 │
│  1. Check email               │
│  2. Add to calendar ↓         │
│  3. Join league chat          │
│                               │
│  [Add to Calendar]            │
│  [View League Details]        │
│  [Download Receipt]           │
│                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                               │
│  Questions?                   │
│  📧 support@theleague.com     │
│  💬 [Start Chat]              │
│                               │
└───────────────────────────────┘
```

### Mobile Cancel Page (Condensed)
```
┌───────────────────────────────┐
│           ⚠️                   │
│  Payment Not Completed        │
│                               │
│  Monday Night Golf League     │
│  $450.00                      │
│                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                               │
│  What happened?               │
│  Your payment wasn't          │
│  processed. Your spot is      │
│  held for 15 minutes.         │
│                               │
│  ⏱️ Time left: 14:32          │
│                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                               │
│  [Try Again - $450]           │
│  Large, prominent button      │
│                               │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                               │
│  Other Options:               │
│  • Save for later             │
│  • View league details        │
│  • Browse other leagues       │
│  • Contact support            │
│                               │
│  💬 Need Help?                │
│  [Start Live Chat]            │
│                               │
└───────────────────────────────┘
```

---

## Key Interactions & Behaviors

### Success Page - On Load
1. Fetch session details from Stripe
2. Verify payment completed successfully
3. Create registration in database
4. Send confirmation email
5. Track conversion in analytics
6. Show confetti animation (optional)
7. Log user into account (if new user)

### Success Page - Add to Calendar
**User clicks "Add to Calendar":**
1. Generate .ics file with:
   - All league dates
   - Venue location
   - Organizer contact
   - League details in description
2. Offer download or direct calendar integration
3. Track calendar add in analytics

### Success Page - Share Registration
**User clicks share:**
1. Generate shareable message
2. Include league invite link
3. Track social shares
4. Award XP for sharing (gamification)

### Cancel Page - Countdown Timer
**15-minute hold period:**
1. Display countdown timer
2. Update every second
3. When expires:
   - Release spot
   - Update UI: "Spot no longer held"
   - Offer to rejoin queue

### Cancel Page - Retry Payment
**User clicks "Complete Registration":**
1. Pre-fill all previously entered info
2. Return to Stripe checkout
3. Track retry attempt
4. Different session ID

### Cancel Page - Save for Later
**User clicks "Save & Finish Later":**
1. Send reminder email with registration link
2. Hold spot for 24 hours (if available)
3. Schedule follow-up emails
4. Track abandonment reason

---

## API Integration Points

**GET `/payment/success?session_id={id}`**
- Retrieve Stripe session details
- Verify payment status = "paid"
- Fetch league/tournament details
- Create registration record
- Send confirmation email
- Return registration data for display

**GET `/payment/cancel?session_id={id}`**
- Retrieve Stripe session details
- Check payment status
- Determine failure reason
- Hold spot for 15 minutes
- Return session data for retry

**POST `/registrations/{id}/cancel`**
- Process cancellation request
- Calculate refund amount
- Initiate Stripe refund
- Send cancellation confirmation
- Update league capacity

**POST `/calendar/generate`**
- Create .ics file with events
- Return download link or calendar URL
- Track calendar integration

---

## Email Confirmations

### Success Email Template
```
Subject: ✅ You're registered for Monday Night Golf League!

Hi Alex,

Great news! Your registration for Monday Night Golf League is confirmed.

📋 REGISTRATION DETAILS
━━━━━━━━━━━━━━━━━━━━━━
League: Monday Night Golf League
Venue: Desert Ridge Golf Club
Start Date: Monday, February 3, 2025
Time: 5:30 PM
Order #: MNG-2025-0142

💳 PAYMENT CONFIRMATION
━━━━━━━━━━━━━━━━━━━━━━
Total Paid: $400.00
Payment Method: •••• 4242
Transaction ID: ch_3Abc123XYZ456

🎯 WHAT'S NEXT?
━━━━━━━━━━━━━━━━━━━━━━
1. Sign the waiver (link below)
2. Add dates to your calendar (attached)
3. Review league rules (link below)
4. Join the league chat (link below)

IMPORTANT DATES:
• Feb 1: Flight assignments announced
• Feb 3: First league night (5:30 PM)

[View Full Details] [Add to Calendar] [Join League Chat]

Need help? Reply to this email or call (555) 123-4567.

See you on the course!
The League Team
```

### Cancellation Reminder Email
```
Subject: ⚠️ Complete your registration for Monday Night Golf

Hi Alex,

We noticed you didn't complete your registration for Monday Night 
Golf League.

Your information is saved - you can finish in just one click!

League: Monday Night Golf League
Amount: $450 ($400 with early bird discount until Jan 15)
Spots Remaining: 4 of 32

[Complete My Registration]

Early bird pricing ends in 20 days - save $50!

Questions? Reply to this email.

Best,
The League Team

[Unsubscribe from registration reminders]
```

---

## Analytics Events to Track

### Success Page
- Payment completed
- Registration created
- Confirmation email sent
- Calendar download
- Social share
- App download click
- League details view
- Receipt download

### Cancel Page
- Payment cancelled/failed
- Cancellation reason (if provided)
- Retry attempt
- Save for later
- Support contact
- Alternative league view
- Session timeout
- Spot release

---

## Error States

### Payment Already Processed
```
╔═══════════════════════════════════════════════════════════════════╗
║  ℹ️ REGISTRATION ALREADY COMPLETE                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  This payment has already been processed.                         ║
║                                                                   ║
║  Order #MNG-2025-0142 was completed on Dec 26, 2024              ║
║                                                                   ║
║  [View Registration Details] [Go to Dashboard]                    ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

### Invalid Session
```
╔═══════════════════════════════════════════════════════════════════╗
║  ❌ SESSION EXPIRED                                               ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  This payment session has expired or is invalid.                  ║
║                                                                   ║
║  Please start a new registration.                                 ║
║                                                                   ║
║  [Browse Leagues] [Return Home]                                   ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

Perfect! Now let me copy all wireframes to the outputs directory and present them all to you.

