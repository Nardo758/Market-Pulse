# Venue Detail Page Wireframe
## `/venues/[id]` - Two-Sided Marketplace Hub

---

## Page Overview

**Purpose:** 
- **For Athletes:** Discover all leagues/events at a venue, follow for updates, view amenities
- **For Venue Managers:** Showcase facility, promote leagues, access admin portal

**URL Pattern:** `/venues/{venue_id}`

**User States:**
- Anonymous visitor
- Logged-in athlete
- Venue manager/admin
- Venue follower

**Key Actions:**
- Browse leagues at venue
- Register for leagues
- Follow venue for notifications
- View upcoming events
- Get directions
- Contact venue
- **[Venue Admin Only]** Access venue management portal

---

## Full Page Wireframe

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Logo] The League     [Search]  [Discover] [My Leagues] [Profile]║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ← Back to Venues / Search Results                               ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │                    HERO SECTION                             │  ║
║ │                                                             │  ║
║ │  [Venue Banner Image - Full width, 400px height]            │  ║
║ │  ┌──────────────────────────────────────────────────────┐   │  ║
║ │  │                                                      │   │  ║
║ │  │  [Overlay gradient dark to transparent]             │   │  ║
║ │  │                                                      │   │  ║
║ │  │  [Venue Logo - bottom left]                         │   │  ║
║ │  │                                                      │   │  ║
║ │  └──────────────────────────────────────────────────────┘   │  ║
║ │                                                             │  ║
║ │  ⛳ Desert Ridge Golf Club                                  │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                              │  ║
║ │                                                             │  ║
║ │  📍 5594 E Clubhouse Dr, Phoenix, AZ 85054                 │  ║
║ │  📞 (480) 333-3333 • 🌐 deserridge.com                     │  ║
║ │  ⭐ 4.8 (342 reviews) • 🏌️ Golf • 4.2 miles away          │  ║
║ │  👥 8 active leagues • 342 total members                    │  ║
║ │                                                             │  ║
║ │  ┌────────────────┐  ┌───────────────┐  ┌──────────────┐  │  ║
║ │  │ ⭐ Follow      │  │ 📍 Directions │  │ 🔗 Share     │  │  ║
║ │  │ 1,234 followers│  │               │  │              │  │  ║
║ │  └────────────────┘  └───────────────┘  └──────────────┘  │  ║
║ │                                                             │  ║
║ │  🔥 New league starting soon! Monday Night Golf - 4 spots  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Photo Gallery - 5-6 images in scrollable carousel]        │  ║
║ │  • Championship course                                      │  ║
║ │  • Clubhouse                                                │  ║
║ │  • Driving range                                            │  ║
║ │  • Restaurant                                               │  ║
║ │  • Pro shop                                                 │  ║
║ │  • Practice facilities                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║           TAB NAVIGATION                                          ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                   ║
║  [Overview] [Leagues] [Events] [About] [Reviews] [Photos]        ║
║   ━━━━━━━━                                                        ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║                    OVERVIEW TAB CONTENT                           ║
║                                                                   ║
║ ┌───────────────────────────────┬─────────────────────────────┐  ║
║ │  ABOUT THIS VENUE             │  QUICK INFO                 │  ║
║ │                               │                             │  ║
║ │  Welcome to Desert Ridge,     │  ┌─────────────────────┐   │  ║
║ │  Phoenix's premier golf       │  │  🏢 VENUE TYPE      │   │  ║
║ │  destination. Our             │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  championship 36-hole         │  │                     │   │  ║
║ │  facility offers exceptional  │  │  • Golf Course      │   │  ║
║ │  playing conditions and       │  │  • Public/Semi-Pvt  │   │  ║
║ │  world-class amenities.       │  │  • 36 holes         │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ │  Designed by legendary Tom    │                             │  ║
║ │  Lehman, our courses provide  │  ┌─────────────────────┐   │  ║
║ │  challenging yet fair play    │  │  ⏰ HOURS           │   │  ║
║ │  for all skill levels.        │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │                               │  │                     │   │  ║
║ │  Key Features:                │  │  Mon-Sun            │   │  ║
║ │  • 36 championship holes      │  │  6:00 AM - 8:00 PM  │   │  ║
║ │  • Full driving range         │  │                     │   │  ║
║ │  • Practice greens            │  │  First tee time:    │   │  ║
║ │  • Golf shop                  │  │  6:30 AM            │   │  ║
║ │  • Restaurant & bar           │  │                     │   │  ║
║ │  • Banquet facilities         │  └─────────────────────┘   │  ║
║ │  • PGA instruction            │                             │  ║
║ │                               │  ┌─────────────────────┐   │  ║
║ │  Perfect for:                 │  │  💵 PRICING         │   │  ║
║ │  ✓ League play                │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  ✓ Corporate events           │  │                     │   │  ║
║ │  ✓ Tournaments                │  │  Green Fees:        │   │  ║
║ │  ✓ Private parties            │  │  • Peak: $95        │   │  ║
║ │  ✓ Wedding receptions         │  │  • Off-peak: $65    │   │  ║
║ │                               │  │  • Twilight: $45    │   │  ║
║ │                               │  │                     │   │  ║
║ │                               │  │  Cart included      │   │  ║
║ │                               │  │  Range balls: $10   │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ └───────────────────────────────┴─────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 FEATURED LEAGUES AT THIS VENUE                          │  ║
║ │                                                             │  ║
║ │  ┌──────────────────────────────────────────────────────┐  │  ║
║ │  │  🏌️ Monday Night Golf League                         │  │  ║
║ │  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  │  ║
║ │  │                                                      │  │  ║
║ │  │  📅 Mondays • 5:30 PM • 18 Holes                    │  │  ║
║ │  │  👥 28/32 players • ⭐ 4.8 (124 reviews)            │  │  ║
║ │  │  💰 $450/season • 🎯 All skill levels               │  │  ║
║ │  │  🔥 Only 4 spots remaining • Early bird ends Jan 15 │  │  ║
║ │  │                                                      │  │  ║
║ │  │  [View Details] [Register Now]                      │  │  ║
║ │  └──────────────────────────────────────────────────────┘  │  ║
║ │                                                             │  ║
║ │  ┌──────────────────────────────────────────────────────┐  │  ║
║ │  │  🏌️ Wednesday Evening Scramble                       │  │  ║
║ │  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  │  ║
║ │  │                                                      │  │  ║
║ │  │  📅 Wednesdays • 6:00 PM • 9 Holes                  │  │  ║
║ │  │  👥 48/48 players • ⭐ 4.9 (89 reviews)             │  │  ║
║ │  │  💰 $200/season • 🎯 Social/Fun format              │  │  ║
║ │  │  ✅ Season in progress (Week 6 of 12)               │  │  ║
║ │  │                                                      │  │  ║
║ │  │  [View Details] [Join Waitlist]                     │  │  ║
║ │  └──────────────────────────────────────────────────────┘  │  ║
║ │                                                             │  ║
║ │  ┌──────────────────────────────────────────────────────┐  │  ║
║ │  │  🏌️ Friday Couples League                            │  │  ║
║ │  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  │  ║
║ │  │                                                      │  │  ║
║ │  │  📅 Fridays • 4:00 PM • 18 Holes                    │  │  ║
║ │  │  👥 24/32 couples • ⭐ 4.7 (56 reviews)             │  │  ║
║ │  │  💰 $900/couple/season • 🎯 All skill levels        │  │  ║
║ │  │  📢 Registration opens Feb 1                        │  │  ║
║ │  │                                                      │  │  ║
║ │  │  [View Details] [Get Notified]                      │  │  ║
║ │  └──────────────────────────────────────────────────────┘  │  ║
║ │                                                             │  ║
║ │  [View All 8 Leagues]                                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📅 UPCOMING EVENTS                                         │  ║
║ │                                                             │  ║
║ │  🏆 Spring Championship                                     │  ║
║ │     Saturday, Mar 15 • 7:00 AM shotgun start               │  ║
║ │     $125/player • 4-person scramble                         │  ║
║ │     [Register]                                              │  ║
║ │                                                             │  ║
║ │  ⛳ Junior Golf Clinic                                      │  ║
║ │     Saturdays in March • 9:00 AM - 11:00 AM                │  ║
║ │     $50/session • Ages 8-16                                 │  ║
║ │     [Learn More]                                            │  ║
║ │                                                             │  ║
║ │  🍴 Sunset Series                                           │  ║
║ │     Every Thursday in April • 5:30 PM                       │  ║
║ │     9 holes + dinner • $65/person                           │  ║
║ │     [Register]                                              │  ║
║ │                                                             │  ║
║ │  [View All Events]                                          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🌟 AMENITIES & FACILITIES                                  │  ║
║ │                                                             │  ║
║ │  Golf Facilities:                  Dining & Social:         │  ║
║ │  ✓ 2 championship courses         ✓ Full-service restaurant│  ║
║ │  ✓ Driving range (covered)        ✓ Bar & lounge           │  ║
║ │  ✓ Putting greens (3)             ✓ Patio dining           │  ║
║ │  ✓ Chipping area                  ✓ Private event rooms    │  ║
║ │  ✓ Practice bunkers               ✓ Banquet hall (200 cap) │  ║
║ │                                                             │  ║
║ │  Services:                        Equipment:                │  ║
║ │  ✓ PGA instruction                ✓ Golf shop               │  ║
║ │  ✓ Club fitting                   ✓ Club rentals           │  ║
║ │  ✓ Golf school                    ✓ GPS carts              │  ║
║ │  ✓ Tournament hosting             ✓ Push carts             │  ║
║ │  ✓ Group outings                  ✓ Club repair           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💬 RECENT REVIEWS                                          │  ║
║ │                                                             │  ║
║ │  ⭐⭐⭐⭐⭐ "Best course in Phoenix!"                          │  ║
║ │  "Course conditions are always perfect. Staff is friendly  │  ║
║ │  and professional. Great value for the quality."            │  ║
║ │  - Mark S. • 3 days ago                                    │  ║
║ │                                                             │  ║
║ │  ⭐⭐⭐⭐⭐ "Love the Monday league"                           │  ║
║ │  "Been playing in the Monday league for 3 years. Well      │  ║
║ │  organized and competitive. Highly recommend!"              │  ║
║ │  - Lisa M. • 1 week ago                                    │  ║
║ │                                                             │  ║
║ │  [View All 342 Reviews]                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Leagues Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Leagues] [Events] [About] [Reviews] [Photos]        ║
║             ━━━━━━━━                                              ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ALL LEAGUES AT DESERT RIDGE GOLF CLUB                            ║
║                                                                   ║
║  8 Active Leagues • 342 Total Members                             ║
║                                                                   ║
║  Filter: [All] [Open] [In Progress] [Upcoming]                    ║
║  Sort: [Start Date] [Popularity] [Price] [Skill Level]            ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏌️ Monday Night Golf League                    [OPEN]      │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  Format: Individual Stroke Play • Net Scoring               │  ║
║ │  📅 Mondays • 5:30 PM • Feb 3 - Apr 21, 2025               │  ║
║ │  ⏱️ 12 weeks + playoffs • 18 holes                          │  ║
║ │  👥 28/32 players • 🎯 All skill levels (flights by hdcp)   │  ║
║ │  💰 $450/season (Early bird: $400 until Jan 15)            │  ║
║ │  ⭐ 4.8 (124 reviews) • 🔥 4 spots remaining                │  ║
║ │                                                             │  ║
║ │  What's Included:                                           │  ║
║ │  • 12 weeks regular season                                  │  ║
║ │  • Playoff tournament                                       │  ║
║ │  • Online scoring & stats                                   │  ║
║ │  • Prizes for flight winners                                │  ║
║ │                                                             │  ║
║ │  [View Details] [Register Now - $450]                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏌️ Wednesday Evening Scramble              [IN PROGRESS]   │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  Format: 4-Person Scramble • Team Play                      │  ║
║ │  📅 Wednesdays • 6:00 PM • In progress (Week 6 of 12)      │  ║
║ │  ⏱️ 12 weeks • 9 holes                                      │  ║
║ │  👥 48/48 players (12 teams) • 🎯 Social/Fun                │  ║
║ │  💰 $200/season                                             │  ║
║ │  ⭐ 4.9 (89 reviews) • ✅ Season started Jan 8              │  ║
║ │                                                             │  ║
║ │  Season runs until Mar 26, 2025                             │  ║
║ │  Next season registration opens March 1                     │  ║
║ │                                                             │  ║
║ │  [View Details] [Join Waitlist] [Get Notified]             │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏌️ Friday Couples League                      [UPCOMING]   │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  Format: Couples Best Ball • Team Play                      │  ║
║ │  📅 Fridays • 4:00 PM • Starts Mar 7, 2025                 │  ║
║ │  ⏱️ 10 weeks • 18 holes                                     │  ║
║ │  👥 24/32 couples • 🎯 All skill levels                     │  ║
║ │  💰 $900/couple/season                                      │  ║
║ │  ⭐ 4.7 (56 reviews) • 📢 Registration opens Feb 1         │  ║
║ │                                                             │  ║
║ │  Perfect for date night golf! Dinner included after play.   │  ║
║ │                                                             │  ║
║ │  [View Details] [Get Notified When Registration Opens]     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [... 5 more leagues ...]                                         ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💡 NOT FINDING WHAT YOU'RE LOOKING FOR?                    │  ║
║ │                                                             │  ║
║ │  • Contact the venue to suggest a new league                │  ║
║ │  • Follow this venue to get notified of new leagues        │  ║
║ │  • Browse leagues at nearby venues                          │  ║
║ │                                                             │  ║
║ │  [Contact Venue] [Follow] [Find Nearby Venues]             │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Events Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Leagues] [Events] [About] [Reviews] [Photos]        ║
║                      ━━━━━━━                                      ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  EVENTS & TOURNAMENTS                                             ║
║                                                                   ║
║  Filter: [Upcoming] [This Month] [Tournaments] [Clinics] [Social] ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 SPRING CHAMPIONSHIP                                     │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  📅 Saturday, March 15, 2025                                │  ║
║ │  ⏰ 7:00 AM shotgun start                                   │  ║
║ │  🏌️ 4-person scramble • Championship Course                 │  ║
║ │  👥 32 teams (128 players) • 64/128 registered              │  ║
║ │  💰 $125/player ($500/team)                                 │  ║
║ │  🎯 All skill levels welcome                                │  ║
║ │                                                             │  ║
║ │  Includes:                                                  │  ║
║ │  • 18 holes with cart                                       │  ║
║ │  • Breakfast before play                                    │  ║
║ │  • Lunch after                                              │  ║
║ │  • Prizes for top 5 teams                                   │  ║
║ │  • Closest to pin & longest drive contests                  │  ║
║ │                                                             │  ║
║ │  [View Details] [Register Team]                             │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  ⛳ JUNIOR GOLF CLINIC                                      │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  📅 Saturdays in March (4 sessions)                         │  ║
║ │  ⏰ 9:00 AM - 11:00 AM                                      │  ║
║ │  🎯 Ages 8-16 • Beginner to Intermediate                    │  ║
║ │  👥 20 spots • 12 registered                                │  ║
║ │  💰 $50/session or $180 for all 4                           │  ║
║ │                                                             │  ║
║ │  PGA instruction covering:                                  │  ║
║ │  • Full swing fundamentals                                  │  ║
║ │  • Short game skills                                        │  ║
║ │  • Course management                                        │  ║
║ │  • Rules & etiquette                                        │  ║
║ │                                                             │  ║
║ │  Equipment provided if needed.                              │  ║
║ │                                                             │  ║
║ │  [View Details] [Register]                                  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🍴 SUNSET SERIES - GOLF & DINE                            │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  📅 Every Thursday in April (4 weeks)                       │  ║
║ │  ⏰ 5:30 PM tee time                                        │  ║
║ │  🏌️ 9 holes scramble format                                 │  ║
║ │  👥 Individual sign-ups (matched into teams)                │  ║
║ │  💰 $65/person per week                                     │  ║
║ │                                                             │  ║
║ │  Includes:                                                  │  ║
║ │  • 9 holes with cart                                        │  ║
║ │  • Range balls before play                                  │  ║
║ │  • Dinner after golf                                        │  ║
║ │  • Drink tickets (2 per person)                             │  ║
║ │  • Weekly prizes                                            │  ║
║ │                                                             │  ║
║ │  Perfect for networking and meeting new golfers!            │  ║
║ │                                                             │  ║
║ │  [View Details] [Register]                                  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [View Full Event Calendar]                                       ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## About Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Leagues] [Events] [About] [Reviews] [Photos]        ║
║                               ━━━━━                               ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ABOUT DESERT RIDGE GOLF CLUB                                     ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  OUR STORY                                                  │  ║
║ │                                                             │  ║
║ │  Desert Ridge Golf Club opened in 2002 as one of           │  ║
║ │  Arizona's premier golf destinations. Designed by PGA Tour │  ║
║ │  champion Tom Lehman, our 36-hole facility combines        │  ║
║ │  challenging play with stunning Sonoran Desert views.      │  ║
║ │                                                             │  ║
║ │  Over the past two decades, we've hosted thousands of      │  ║
║ │  leagues, tournaments, and events while maintaining our    │  ║
║ │  commitment to exceptional course conditions and           │  ║
║ │  outstanding service.                                       │  ║
║ │                                                             │  ║
║ │  Whether you're joining a weeknight league, competing in   │  ║
║ │  a championship, or enjoying a casual round with friends,  │  ║
║ │  Desert Ridge offers an unmatched golf experience.         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  COURSE INFORMATION                                         │  ║
║ │                                                             │  ║
║ │  CHAMPIONSHIP COURSE (The Accolades)                        │  ║
║ │  • Par: 72                                                  │  ║
║ │  • Length: 7,002 yards (championship tees)                  │  ║
║ │  • Rating: 73.8 / Slope: 142                               │  ║
║ │  • Designer: Tom Lehman                                     │  ║
║ │  • Opened: 2002                                             │  ║
║ │  • Type: Desert target-style                                │  ║
║ │                                                             │  ║
║ │  RESORT COURSE (The Wildflower)                             │  ║
║ │  • Par: 71                                                  │  ║
║ │  • Length: 6,784 yards (championship tees)                  │  ║
║ │  • Rating: 72.1 / Slope: 136                               │  ║
║ │  • Designer: Tom Lehman                                     │  ║
║ │  • Opened: 2002                                             │  ║
║ │  • Type: Desert links-style                                 │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FACILITIES & AMENITIES                                     │  ║
║ │                                                             │  ║
║ │  Practice Facilities:                                       │  ║
║ │  • Double-decker driving range (covered & heated)           │  ║
║ │  • 3 large putting greens                                   │  ║
║ │  • Chipping area with bunkers                               │  ║
║ │  • Practice bunker complex                                  │  ║
║ │                                                             │  ║
║ │  Golf Services:                                             │  ║
║ │  • PGA-staffed golf shop (10,000 sq ft)                    │  ║
║ │  • Custom club fitting studio                               │  ║
║ │  • Club repair services                                     │  ║
║ │  • Equipment rentals (clubs, GPS carts, push carts)        │  ║
║ │  • Professional instruction                                 │  ║
║ │                                                             │  ║
║ │  Dining:                                                    │  ║
║ │  • Full-service restaurant                                  │  ║
║ │  • Outdoor patio dining                                     │  ║
║ │  • Bar & lounge                                             │  ║
║ │  • Grab-and-go café                                         │  ║
║ │  • Beverage cart service on course                          │  ║
║ │                                                             │  ║
║ │  Events:                                                    │  ║
║ │  • Banquet hall (seats 200)                                 │  ║
║ │  • Private meeting rooms                                    │  ║
║ │  • Outdoor event spaces                                     │  ║
║ │  • Wedding & reception services                             │  ║
║ │  • Corporate outing packages                                │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  HOURS & CONTACT                                            │  ║
║ │                                                             │  ║
║ │  Golf Operations:                                           │  ║
║ │  Monday - Sunday: 6:00 AM - 8:00 PM                        │  ║
║ │  First tee time: 6:30 AM                                    │  ║
║ │  Last tee time: Varies by season (sunset)                   │  ║
║ │                                                             │  ║
║ │  Golf Shop:                                                 │  ║
║ │  Monday - Sunday: 6:00 AM - 7:00 PM                        │  ║
║ │                                                             │  ║
║ │  Restaurant:                                                │  ║
║ │  Monday - Sunday: 7:00 AM - 9:00 PM                        │  ║
║ │  Happy Hour: 3:00 PM - 6:00 PM                             │  ║
║ │                                                             │  ║
║ │  Contact Information:                                       │  ║
║ │  📞 Main: (480) 333-3333                                    │  ║
║ │  📞 Tee Times: (480) 333-3334                              │  ║
║ │  📞 Events: (480) 333-3335                                 │  ║
║ │  📧 info@desertridge.com                                    │  ║
║ │  🌐 www.desertridge.com                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  LOCATION & DIRECTIONS                                      │  ║
║ │                                                             │  ║
║ │  📍 5594 E Clubhouse Dr                                     │  ║
║ │     Phoenix, AZ 85054                                       │  ║
║ │                                                             │  ║
║ │  [Embedded Google Map]                                      │  ║
║ │                                                             │  ║
║ │  From Phoenix Sky Harbor Airport:                           │  ║
║ │  • Take AZ-202 Loop E to AZ-51 N                           │  ║
║ │  • Exit on E Greenway Pkwy                                  │  ║
║ │  • Turn right on Tatum Blvd                                 │  ║
║ │  • Approximately 25 minutes (15 miles)                      │  ║
║ │                                                             │  ║
║ │  Parking: Free parking available                            │  ║
║ │                                                             │  ║
║ │  [Get Directions]                                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  POLICIES                                                   │  ║
║ │                                                             │  ║
║ │  Dress Code:                                                │  ║
║ │  • Collared shirts required                                 │  ║
║ │  • No denim or cargo shorts                                 │  ║
║ │  • Golf shoes or soft spikes only                           │  ║
║ │  • Appropriate athletic attire                              │  ║
║ │                                                             │  ║
║ │  Pace of Play:                                              │  ║
║ │  • Maintain 4 hour 15 minute pace                          │  ║
║ │  • Ready golf encouraged                                    │  ║
║ │  • Course marshals monitor pace                             │  ║
║ │                                                             │  ║
║ │  Cancellation:                                              │  ║
║ │  • 24-hour notice for tee time cancellations               │  ║
║ │  • Weather-related closures announced by 6:00 AM           │  ║
║ │                                                             │  ║
║ │  Handicap:                                                  │  ║
║ │  • GHIN posting available at golf shop                     │  ║
║ │  • Handicap certificate may be required for tournaments    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Reviews Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Leagues] [Events] [About] [Reviews] [Photos]        ║
║                                       ━━━━━━━━                    ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  VENUE REVIEWS                                                    ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  OVERALL RATING                                             │  ║
║ │                                                             │  ║
║ │       ⭐ 4.8 out of 5                                        │  ║
║ │       Based on 342 reviews                                  │  ║
║ │                                                             │  ║
║ │  5 stars ███████████████████████████████░░ 245 (72%)       │  ║
║ │  4 stars ████████████░░░░░░░░░░░░░░░░░░░░  78 (23%)       │  ║
║ │  3 stars ██░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  15 (4%)        │  ║
║ │  2 stars █░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░   3 (1%)        │  ║
║ │  1 star  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░   1 (0%)        │  ║
║ │                                                             │  ║
║ │  [Write a Review]                                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  RATING BREAKDOWN                                           │  ║
║ │                                                             │  ║
║ │  Course Condition      ⭐ 4.9                               │  ║
║ │  Staff & Service       ⭐ 4.8                               │  ║
║ │  Facilities            ⭐ 4.7                               │  ║
║ │  Value for Money       ⭐ 4.6                               │  ║
║ │  League Organization   ⭐ 4.9                               │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  Sort: [Most Recent] [Highest Rated] [Lowest Rated]               ║
║  Filter: [All] [Leagues] [General Play] [Events]                  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Avatar] Mark S.                              ⭐⭐⭐⭐⭐      │  ║
║ │           Verified Member • League Player                   │  ║
║ │           3 days ago                                        │  ║
║ │                                                             │  ║
║ │  "Best course in Phoenix!"                                  │  ║
║ │                                                             │  ║
║ │  I've been playing Desert Ridge for 5 years and it never   │  ║
║ │  disappoints. Course conditions are always perfect, even   │  ║
║ │  in summer. Staff is friendly and professional. The        │  ║
║ │  practice facilities are top-notch. Great value for the    │  ║
║ │  quality you get.                                           │  ║
║ │                                                             │  ║
║ │  Course Condition: ⭐⭐⭐⭐⭐                                  │  ║
║ │  Staff & Service: ⭐⭐⭐⭐⭐                                   │  ║
║ │  Value: ⭐⭐⭐⭐⭐                                             │  ║
║ │                                                             │  ║
║ │  Helpful? 👍 24  👎 1                                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Avatar] Lisa M.                              ⭐⭐⭐⭐⭐      │  ║
║ │           Verified Member • Monday League                   │  ║
║ │           1 week ago                                        │  ║
║ │                                                             │  ║
║ │  "Love the Monday league"                                   │  ║
║ │                                                             │  ║
║ │  Been playing in the Monday league for 3 years. The        │  ║
║ │  organizer Sarah is fantastic - always on top of           │  ║
║ │  everything. Course is challenging but fair. Great group   │  ║
║ │  of people. Highly recommend joining a league here!         │  ║
║ │                                                             │  ║
║ │  Course Condition: ⭐⭐⭐⭐⭐                                  │  ║
║ │  League Organization: ⭐⭐⭐⭐⭐                               │  ║
║ │                                                             │  ║
║ │  Helpful? 👍 18  👎 0                                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Avatar] Robert T.                            ⭐⭐⭐⭐        │  ║
║ │           Verified Member • General Play                    │  ║
║ │           2 weeks ago                                       │  ║
║ │                                                             │  ║
║ │  "Great course, a bit pricey"                               │  ║
║ │                                                             │  ║
║ │  Course is beautiful and well-maintained. Staff is very    │  ║
║ │  helpful. Only complaint is the price - $95 for peak times │  ║
║ │  is steep compared to other courses. But you do get what   │  ║
║ │  you pay for.                                               │  ║
║ │                                                             │  ║
║ │  Course Condition: ⭐⭐⭐⭐⭐                                  │  ║
║ │  Value: ⭐⭐⭐                                                │  ║
║ │                                                             │  ║
║ │  Helpful? 👍 12  👎 3                                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [Load More Reviews]                                              ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Photos Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Leagues] [Events] [About] [Reviews] [Photos]        ║
║                                                  ━━━━━━           ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  VENUE PHOTOS                                                     ║
║                                                                   ║
║  156 photos • View: [All] [Courses] [Facilities] [Events]        ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  COURSE PHOTOS                                              │  ║
║ │                                                             │  ║
║ │  [Photo Grid - 3 columns]                                   │  ║
║ │                                                             │  ║
║ │  ┌──────────┐ ┌──────────┐ ┌──────────┐                    │  ║
║ │  │ [Photo]  │ │ [Photo]  │ │ [Photo]  │                    │  ║
║ │  │ Hole #7  │ │ Hole #12 │ │ Hole #18 │                    │  ║
║ │  │ Signature│ │ Par 3    │ │ Finishing│                    │  ║
║ │  └──────────┘ └──────────┘ └──────────┘                    │  ║
║ │                                                             │  ║
║ │  ┌──────────┐ ┌──────────┐ ┌──────────┐                    │  ║
║ │  │ [Photo]  │ │ [Photo]  │ │ [Photo]  │                    │  ║
║ │  │ Practice │ │ Clubhouse│ │ Sunset   │                    │  ║
║ │  │ Green    │ │ View     │ │ Tee Shot │                    │  ║
║ │  └──────────┘ └──────────┘ └──────────┘                    │  ║
║ │                                                             │  ║
║ │  [View All Course Photos (87)]                              │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FACILITIES                                                 │  ║
║ │                                                             │  ║
║ │  [Photo Grid]                                               │  ║
║ │  • Driving range (covered)                                  │  ║
║ │  • Golf shop interior                                       │  ║
║ │  • Restaurant & patio                                       │  ║
║ │  • Banquet hall                                             │  ║
║ │  • Locker rooms                                             │  ║
║ │                                                             │  ║
║ │  [View All Facility Photos (42)]                            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  EVENT PHOTOS                                               │  ║
║ │                                                             │  ║
║ │  [Photo Grid]                                               │  ║
║ │  • 2024 Spring Championship                                 │  ║
║ │  • Monday League action shots                               │  ║
║ │  • Wedding reception setup                                  │  ║
║ │  • Corporate outing groups                                  │  ║
║ │                                                             │  ║
║ │  [View All Event Photos (27)]                               │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💡 SHARE YOUR PHOTOS                                       │  ║
║ │                                                             │  ║
║ │  Tag us @desertridgegolf or #desertridgegolf on social     │  ║
║ │  media and your photos may appear here!                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## User State Variations

### Anonymous Visitor
```
Hero CTA: [⭐ Follow] → Redirects to /login
League registration buttons → Redirects to /login
Review form: "Sign in to write a review"
```

### Logged-In Athlete
```
Hero section:
┌─────────────────────────────────────────────────────────────┐
│  ⭐ Follow (1,234 followers)                                 │
│  ✓ Following • [Notification Settings]                      │
│                                                             │
│  Get notified about:                                        │
│  ☑ New leagues                                              │
│  ☑ Upcoming events                                          │
│  ☑ Special offers                                           │
│  ☐ General announcements                                    │
└─────────────────────────────────────────────────────────────┘
```

### Venue Manager/Admin
```
Additional admin bar at top:
┌─────────────────────────────────────────────────────────────┐
│  🛠️ VENUE ADMIN DASHBOARD                                   │
│  [Edit Venue Profile] [Create League] [Post Event]         │
│  [View Analytics] [Manage Registrations] [Announcements]   │
└─────────────────────────────────────────────────────────────┘
```

---

## Mobile Optimization

### Mobile Hero (Stacked)
```
┌───────────────────────────────┐
│ [Hero Image]                  │
│                               │
│ ⛳ Desert Ridge Golf Club     │
│ ━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│                               │
│ ⭐ 4.8 (342) • 4.2 mi         │
│ 8 leagues • 342 members       │
│                               │
│ [Follow] [Directions] [Share] │
│                               │
│ [Swipeable Photo Gallery]    │
└───────────────────────────────┘
```

### Mobile Tabs (Horizontal Scroll)
```
┌──────────────────────────────────────────┐
│ [Overview] [Leagues] [Events] [About] → │
└──────────────────────────────────────────┘
```

### Mobile League Cards (Stacked)
```
┌───────────────────────────────┐
│ 🏌️ Monday Night Golf League  │
│                               │
│ Mondays • 5:30 PM             │
│ 28/32 • $450 • ⭐ 4.8         │
│                               │
│ [View] [Register]             │
└───────────────────────────────┘
```

---

## Key Interactions & Behaviors

### Follow/Unfollow Venue
**Logged-in user clicks "Follow":**
1. Toggle follow status
2. Show notification preferences modal
3. Update follower count
4. Add venue to user's "Following" list
5. Show confirmation toast

### Get Directions
**User clicks "Get Directions":**
1. Detect user's location (with permission)
2. Open Google Maps with directions
3. Track click in analytics

### Share Venue
**User clicks "Share":**
1. Generate shareable link
2. Show share modal with options:
   - Copy link
   - Share to Twitter
   - Share to Facebook
   - Share via email
3. Track share in analytics

### Contact Venue
**User clicks contact (phone/email):**
1. Open native phone/email app
2. Pre-populate venue information
3. Track interaction

### Register for League
**From league card:**
1. If anonymous → redirect to /login
2. If logged in → open registration flow
3. Navigate to `/leagues/{league_id}/checkout`

### Join Waitlist
**For full leagues:**
1. Capture user email
2. Send confirmation
3. Add to waitlist queue
4. Auto-notify when spot opens

---

## API Integration Points

**GET `/venues/{id}`**
- Fetch venue details
- Include stats (leagues, members, followers)
- Return follow status for current user

**GET `/venues/{id}/leagues`**
- Fetch all leagues at venue
- Filter by status (open, in-progress, upcoming)
- Sort by start date, popularity, price

**GET `/venues/{id}/events`**
- Fetch upcoming events/tournaments
- Include registration status

**GET `/venues/{id}/reviews`**
- Fetch venue reviews
- Paginated results
- Filter by category

**GET `/venues/{id}/photos`**
- Fetch venue photos
- Category filtering (course, facilities, events)

**POST `/venues/{id}/follow`**
- Toggle follow status
- Update notification preferences
- Return updated follower count

**POST `/venues/{id}/reviews`**
- Submit new review
- Requires authentication
- Include rating breakdown

---

## SEO & Metadata

**Title:**
`{Venue Name} - {Sport} Leagues & Events in {City} | The League`

**Description:**
`Discover {Number} leagues and events at {Venue Name} in {City}. {Sport} leagues, tournaments, and clinics. {Rating} stars from {Review Count} reviews.`

**Structured Data (JSON-LD):**
```json
{
  "@type": "SportsActivityLocation",
  "name": "Desert Ridge Golf Club",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "5594 E Clubhouse Dr",
    "addressLocality": "Phoenix",
    "addressRegion": "AZ",
    "postalCode": "85054"
  },
  "telephone": "(480) 333-3333",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.8",
    "reviewCount": "342"
  }
}
```

---

## Analytics Events to Track

- Page view
- Tab switch
- Follow/unfollow
- Get directions click
- Share link generated
- League card click
- League registration initiated
- Event registration click
- Photo gallery interaction
- Review submitted
- Phone/email contact click
- External website click

---

## Empty States

### No Leagues
```
╔═══════════════════════════════════════════════════════════════════╗
║  📭 NO ACTIVE LEAGUES                                             ║
║                                                                   ║
║  This venue doesn't have any active leagues right now.            ║
║                                                                   ║
║  What you can do:                                                 ║
║  • Follow this venue to get notified when leagues are posted     ║
║  • Check upcoming events                                          ║
║  • Browse leagues at nearby venues                                ║
║                                                                   ║
║  [Follow Venue] [Find Nearby Venues]                              ║
╚═══════════════════════════════════════════════════════════════════╝
```

### No Events
```
╔═══════════════════════════════════════════════════════════════════╗
║  📅 NO UPCOMING EVENTS                                            ║
║                                                                   ║
║  This venue doesn't have any events scheduled.                    ║
║                                                                   ║
║  Follow this venue to be notified when new events are posted.    ║
║                                                                   ║
║  [Follow Venue]                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

### No Reviews
```
╔═══════════════════════════════════════════════════════════════════╗
║  💬 NO REVIEWS YET                                                ║
║                                                                   ║
║  Be the first to review this venue!                               ║
║                                                                   ║
║  [Write a Review]                                                 ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

This comprehensive wireframe covers the entire venue detail experience from both athlete and venue manager perspectives. Next, I'll create the **Tournament Detail page** (`/tournaments/[id]`). Ready?

