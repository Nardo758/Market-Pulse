# League Detail Page Wireframe
## `/leagues/[id]` - Core Conversion Page

---

## Page Overview

**Purpose:** Convert discovery into registration by showing complete league information and making it easy to join.

**URL Pattern:** `/leagues/{league_id}`

**User States:**
- Anonymous visitor
- Logged-in user (not registered)
- Logged-in user (registered for this league)
- League organizer/admin

**Key Actions:**
- Register for league (→ payment flow)
- View schedule
- Check standings
- See roster/teams
- Follow league for updates
- Contact organizer

---

## Full Page Wireframe

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Logo] The League     [Search]  [Discover] [My Leagues] [Profile]║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ← Back to [Sport Channel] / Search Results                      ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │                    HERO SECTION                             │  ║
║ │                                                             │  ║
║ │  [League Badge/Logo]                                        │  ║
║ │                                                             │  ║
║ │  🏌️ Monday Night Golf League                                │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                          │  ║
║ │                                                             │  ║
║ │  📍 Desert Ridge Golf Club                                  │  ║
║ │  📅 Mondays • 5:30 PM • 18 Holes                           │  ║
║ │  👥 28/32 players • ⭐ 4.8 (124 reviews)                     │  ║
║ │  💰 $450/season • 🎯 All skill levels                        │  ║
║ │                                                             │  ║
║ │  ┌─────────────────┐  ┌──────────────┐  ┌──────────────┐   │  ║
║ │  │ Register Now    │  │ Follow       │  │ Share        │   │  ║
║ │  │ $450            │  │ ⭐ Following  │  │ 🔗 Link      │   │  ║
║ │  └─────────────────┘  └──────────────┘  └──────────────┘   │  ║
║ │                                                             │  ║
║ │  ⏰ Early bird pricing ends Jan 15 - Save $50!              │  ║
║ │  🔥 Only 4 spots remaining                                  │  ║
║ │                                                             │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Gallery: 4-5 photos of course/past league action]         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║           TAB NAVIGATION                                          ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                   ║
║  [Overview] [Schedule] [Standings] [Roster] [Venue] [Reviews]    ║
║   ━━━━━━                                                          ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║                    OVERVIEW TAB CONTENT                           ║
║                                                                   ║
║ ┌───────────────────────────────┬─────────────────────────────┐  ║
║ │  ABOUT THIS LEAGUE            │  QUICK STATS                │  ║
║ │                               │                             │  ║
║ │  Join our friendly Monday     │  ┌─────────────────────┐   │  ║
║ │  night league for 12 weeks    │  │  📊 Current Season  │   │  ║
║ │  of competitive stroke play.  │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  Handicaps welcome. Flights   │  │                     │   │  ║
║ │  by skill level ensure fair   │  │  Week 8 of 12       │   │  ║
║ │  competition.                 │  │  Progress: 67%      │   │  ║
║ │                               │  │  ████████░░░        │   │  ║
║ │  What's Included:             │  └─────────────────────┘   │  ║
║ │  ✓ 12 weeks of play           │                             │  ║
║ │  ✓ Handicap integration       │  ┌─────────────────────┐   │  ║
║ │  ✓ Prizes for flight winners  │  │  👥 Participants    │   │  ║
║ │  ✓ End-of-season tournament   │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  ✓ Online scoring & stats     │  │                     │   │  ║
║ │                               │  │  Registered: 28     │   │  ║
║ │  Format:                      │  │  Capacity: 32       │   │  ║
║ │  • Individual stroke play     │  │  Waitlist: 3        │   │  ║
║ │  • 18 holes                   │  │                     │   │  ║
║ │  • Net scoring (handicaps)    │  │  88% Full           │   │  ║
║ │  • 4 flights by handicap      │  │  ████████████░░     │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ │  Schedule:                    │                             │  ║
║ │  Start: Monday, Jan 6, 2025   │  ┌─────────────────────┐   │  ║
║ │  Time: 5:30 PM tee times      │  │  💵 Pricing         │   │  ║
║ │  Duration: 12 weeks           │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  Playoffs: Mar 24-31          │  │                     │   │  ║
║ │                               │  │  Regular: $450      │   │  ║
║ │  Requirements:                │  │  Early Bird: $400   │   │  ║
║ │  • Valid GHIN handicap        │  │  (until Jan 15)     │   │  ║
║ │  • Club membership or         │  │                     │   │  ║
║ │    green fee payment          │  │  Includes:          │   │  ║
║ │  • Commitment to play         │  │  • League entry     │   │  ║
║ │    all 12 weeks               │  │  • Prize pool       │   │  ║
║ │                               │  │  • Scoring system   │   │  ║
║ │                               │  │                     │   │  ║
║ │                               │  │  Green fees paid    │   │  ║
║ │                               │  │  separately to      │   │  ║
║ │                               │  │  venue ($25/round)  │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ └───────────────────────────────┴─────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  ORGANIZER INFO                                             │  ║
║ │                                                             │  ║
║ │  [Photo] Sarah Chen                                         │  ║
║ │          League Director                                    │  ║
║ │          Member since 2019                                  │  ║
║ │          15 leagues organized                               │  ║
║ │                                                             │  ║
║ │          [Message Organizer]  [Report Issue]               │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  REGISTRATION INFORMATION                                   │  ║
║ │                                                             │  ║
║ │  Registration Timeline:                                     │  ║
║ │  • Opens: Dec 1, 2024                                       │  ║
║ │  • Early Bird Ends: Jan 15, 2025                           │  ║
║ │  • Registration Closes: Jan 30, 2025                       │  ║
║ │  • Season Starts: Feb 3, 2025                              │  ║
║ │                                                             │  ║
║ │  Payment Options:                                           │  ║
║ │  ✓ Credit/Debit Card (Stripe)                              │  ║
║ │  ✓ Full payment upfront                                     │  ║
║ │  ✓ Payment plan available (3 installments)                 │  ║
║ │                                                             │  ║
║ │  Cancellation Policy:                                       │  ║
║ │  • Full refund until Jan 20                                │  ║
║ │  • 50% refund until Feb 1                                  │  ║
║ │  • No refunds after season starts                          │  ║
║ │                                                             │  ║
║ │  Waitlist: If league is full, join the waitlist to be      │  ║
║ │  notified of openings.                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  PAST SEASONS                                               │  ║
║ │                                                             │  ║
║ │  ┌──────────────┬──────────────┬──────────────┐            │  ║
║ │  │ Fall 2024    │ Summer 2024  │ Spring 2024  │            │  ║
║ │  │ 32 players   │ 28 players   │ 30 players   │            │  ║
║ │  │ ⭐ 4.9       │ ⭐ 4.8       │ ⭐ 4.7       │            │  ║
║ │  │ View Results │ View Results │ View Results │            │  ║
║ │  └──────────────┴──────────────┴──────────────┘            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  WHAT PLAYERS ARE SAYING                                    │  ║
║ │                                                             │  ║
║ │  ⭐⭐⭐⭐⭐ "Best league I've joined!"                         │  ║
║ │  "Great competition, well-organized, friendly group."       │  ║
║ │  - Mike T. (Handicap 14.2) • 2 weeks ago                   │  ║
║ │                                                             │  ║
║ │  ⭐⭐⭐⭐⭐ "Perfect for working professionals"               │  ║
║ │  "Monday evening time works great for my schedule."         │  ║
║ │  - Jennifer W. (Handicap 18.5) • 1 month ago               │  ║
║ │                                                             │  ║
║ │  ⭐⭐⭐⭐ "Good value"                                         │  ║
║ │  "Pricing is fair for what you get. Course is in great     │  ║
║ │  shape."                                                    │  ║
║ │  - David P. (Handicap 9.8) • 1 month ago                   │  ║
║ │                                                             │  ║
║ │  [View All 124 Reviews]                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  STICKY BOTTOM CTA (appears on scroll)                      │  ║
║ │                                                             │  ║
║ │  Monday Night Golf League • $450 • 4 spots left            │  ║
║ │  [Register Now]  [Add to Waitlist]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Schedule Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Schedule] [Standings] [Roster] [Venue] [Reviews]    ║
║             ━━━━━━━━                                              ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  SEASON SCHEDULE                                                  ║
║                                                                   ║
║  View: [Calendar] [List] | Filter: [All Weeks] [Upcoming] [Past] ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  Week 1 • Mon, Feb 3, 2025 • 5:30 PM                        │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                    │  ║
║ │  Opening Round                                              │  ║
║ │  📍 Desert Ridge Golf Club - Championship Course            │  ║
║ │                                                             │  ║
║ │  Flight A Pairings:                                         │  ║
║ │  • Mike Thompson (8.2) vs. Sarah Chen (9.5)                │  ║
║ │  • John Martinez (7.8) vs. Lisa Anderson (10.1)            │  ║
║ │  [View All Pairings]                                        │  ║
║ │                                                             │  ║
║ │  [Add to Calendar] [Get Directions]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  Week 2 • Mon, Feb 10, 2025 • 5:30 PM                       │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                    │  ║
║ │  Regular Play                                               │  ║
║ │  📍 Desert Ridge Golf Club - Championship Course            │  ║
║ │                                                             │  ║
║ │  ⚠️ Pairings posted 48 hours before tee time                │  ║
║ │                                                             │  ║
║ │  [Add to Calendar] [Get Directions]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [... Weeks 3-11 ...]                                             ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  Week 12 • Mon, Apr 21, 2025 • 5:30 PM                      │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                    │  ║
║ │  🏆 Championship Round                                      │  ║
║ │  📍 Desert Ridge Golf Club - Championship Course            │  ║
║ │                                                             │  ║
║ │  Top 8 from each flight advance to match play playoffs     │  ║
║ │                                                             │  ║
║ │  [Add to Calendar] [Get Directions]                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  IMPORTANT DATES                                            │  ║
║ │  • Feb 3: Season opener                                     │  ║
║ │  • Mar 10: Mid-season social (optional)                    │  ║
║ │  • Apr 21: Regular season finale                           │  ║
║ │  • Apr 28 & May 5: Playoffs (if applicable)                │  ║
║ │  • May 12: Awards ceremony                                 │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Standings Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Schedule] [Standings] [Roster] [Venue] [Reviews]    ║
║                        ━━━━━━━━━━                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  CURRENT STANDINGS                                                ║
║                                                                   ║
║  View: [Flight A] [Flight B] [Flight C] [Flight D] [Overall]     ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FLIGHT A (Handicap 0-9)                                    │  ║
║ │  After Week 8 of 12                                         │  ║
║ │                                                             │  ║
║ │  Rank | Player          | Hdcp | Rounds | Avg Net | Points  │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  🥇 1 | Mike Thompson   | 8.2  | 8      | 71.2    | 24      │  ║
║ │    2 | Sarah Chen      | 9.5  | 8      | 72.8    | 22      │  ║
║ │    3 | John Martinez   | 7.8  | 7      | 73.1    | 20      │  ║
║ │    4 | Lisa Anderson   | 10.1 | 8      | 74.5    | 18      │  ║
║ │    5 | David Park      | 8.9  | 8      | 75.0    | 16      │  ║
║ │    6 | Jennifer Wu     | 9.2  | 7      | 75.8    | 14      │  ║
║ │    7 | Robert Lee      | 8.5  | 8      | 76.2    | 12      │  ║
║ │    8 | Maria Garcia    | 9.8  | 7      | 77.1    | 10      │  ║
║ │                                                             │  ║
║ │  [View Full Standings]                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  RECENT RESULTS (Last 3 Rounds)                             │  ║
║ │                                                             │  ║
║ │  Week 8 • Feb 24                                            │  ║
║ │  Low Net: Mike Thompson - 69                                │  ║
║ │  Low Gross: John Martinez - 76                              │  ║
║ │                                                             │  ║
║ │  Week 7 • Feb 17                                            │  ║
║ │  Low Net: Sarah Chen - 70                                   │  ║
║ │  Low Gross: Mike Thompson - 77                              │  ║
║ │                                                             │  ║
║ │  Week 6 • Feb 10                                            │  ║
║ │  Low Net: Mike Thompson - 68 🔥                             │  ║
║ │  Low Gross: David Park - 75                                 │  ║
║ │                                                             │  ║
║ │  [View All Results]                                         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  PLAYOFF QUALIFICATION                                      │  ║
║ │                                                             │  ║
║ │  Top 8 in each flight advance to playoffs                  │  ║
║ │                                                             │  ║
║ │  Flight A: 8 qualified (4 weeks remaining)                 │  ║
║ │  Flight B: 7 qualified, 1 on the bubble                    │  ║
║ │  Flight C: 6 qualified, 2 spots open                       │  ║
║ │  Flight D: 8 qualified                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Roster Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Schedule] [Standings] [Roster] [Venue] [Reviews]    ║
║                                   ━━━━━━                          ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  LEAGUE ROSTER                                                    ║
║                                                                   ║
║  28 Registered Players • 4 Open Spots • 3 on Waitlist            ║
║                                                                   ║
║  [Search Players...] | Filter: [All Flights] [Flight A] [B] [C] [D] ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FLIGHT A (8 players)                                       │  ║
║ │                                                             │  ║
║ │  [Avatar] Mike Thompson                                     │  ║
║ │           Handicap: 8.2 • Member since 2019                │  ║
║ │           📊 8 rounds played this season                    │  ║
║ │           🏆 2023 Flight A Champion                         │  ║
║ │           [View Profile] [Message]                          │  ║
║ │                                                             │  ║
║ │  [Avatar] Sarah Chen                                        │  ║
║ │           Handicap: 9.5 • Member since 2020                │  ║
║ │           📊 8 rounds played this season                    │  ║
║ │           [View Profile] [Message]                          │  ║
║ │                                                             │  ║
║ │  ... [6 more Flight A players] ...                          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FLIGHT B (7 players)                                       │  ║
║ │  [collapsed, click to expand]                               │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FLIGHT C (7 players)                                       │  ║
║ │  [collapsed]                                                │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FLIGHT D (6 players)                                       │  ║
║ │  [collapsed]                                                │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💡 JOIN THE LEAGUE                                         │  ║
║ │                                                             │  ║
║ │  4 spots still available!                                   │  ║
║ │  Register now to secure your spot.                          │  ║
║ │                                                             │  ║
║ │  [Register Now - $450]                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Venue Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Schedule] [Standings] [Roster] [Venue] [Reviews]    ║
║                                            ━━━━━                  ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  VENUE INFORMATION                                                ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Venue Logo]  Desert Ridge Golf Club                       │  ║
║ │                                                             │  ║
║ │  ⭐ 4.8 (342 reviews) • 📍 4.2 miles away                   │  ║
║ │                                                             │  ║
║ │  5594 E Clubhouse Dr                                        │  ║
║ │  Phoenix, AZ 85054                                          │  ║
║ │  📞 (480) 333-3333                                          │  ║
║ │                                                             │  ║
║ │  [View Venue Profile] [Get Directions] [⭐ Follow]          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Venue Photos - 4-5 images in gallery]                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  COURSE DETAILS                                             │  ║
║ │                                                             │  ║
║ │  Championship Course                                        │  ║
║ │  • Par: 72                                                  │  ║
║ │  • Length: 7,002 yards                                      │  ║
║ │  • Rating: 73.8 / Slope: 142                               │  ║
║ │  • Designed by: Tom Lehman                                  │  ║
║ │                                                             │  ║
║ │  Amenities:                                                 │  ║
║ │  ✓ Driving range                                            │  ║
║ │  ✓ Putting green                                            │  ║
║ │  ✓ Pro shop                                                 │  ║
║ │  ✓ Restaurant & bar                                         │  ║
║ │  ✓ GPS carts                                                │  ║
║ │  ✓ Club rentals                                             │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  OTHER LEAGUES AT THIS VENUE                                │  ║
║ │                                                             │  ║
║ │  🏌️ Wednesday Evening Scramble                              │  ║
║ │     9 holes • 6:00 PM • $200/season                         │  ║
║ │                                                             │  ║
║ │  🏌️ Friday Couples League                                   │  ║
║ │     18 holes • 4:00 PM • $900/couple                        │  ║
║ │                                                             │  ║
║ │  [View All Leagues at This Venue]                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📍 MAP & DIRECTIONS                                        │  ║
║ │                                                             │  ║
║ │  [Embedded Google Map]                                      │  ║
║ │                                                             │  ║
║ │  [Get Directions]                                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Reviews Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Schedule] [Standings] [Roster] [Venue] [Reviews]    ║
║                                                     ━━━━━━━       ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  PLAYER REVIEWS                                                   ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  OVERALL RATING                                             │  ║
║ │                                                             │  ║
║ │       ⭐ 4.8 out of 5                                        │  ║
║ │       Based on 124 reviews                                  │  ║
║ │                                                             │  ║
║ │  5 stars ████████████████████████████████░░ 85 (69%)       │  ║
║ │  4 stars ████████████░░░░░░░░░░░░░░░░░░░░ 32 (26%)       │  ║
║ │  3 stars ██░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  5 (4%)        │  ║
║ │  2 stars █░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  2 (2%)        │  ║
║ │  1 star  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  0 (0%)        │  ║
║ │                                                             │  ║
║ │  [Write a Review]                                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  Sort by: [Most Recent] [Highest Rated] [Lowest Rated]           ║
║  Filter: [All Seasons] [Current Season] [Past Seasons]           ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Avatar] Mike T.                              ⭐⭐⭐⭐⭐      │  ║
║ │           Handicap 14.2 • Verified Member                   │  ║
║ │           2 weeks ago                                       │  ║
║ │                                                             │  ║
║ │  "Best league I've joined!"                                 │  ║
║ │                                                             │  ║
║ │  Great competition, well-organized, and the organizer       │  ║
║ │  Sarah is fantastic. The flight system ensures fair play   │  ║
║ │  and the online scoring makes it easy to track progress.   │  ║
║ │  Highly recommend!                                          │  ║
║ │                                                             │  ║
║ │  Helpful? 👍 12  👎 0                                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Avatar] Jennifer W.                          ⭐⭐⭐⭐⭐      │  ║
║ │           Handicap 18.5 • Verified Member                   │  ║
║ │           1 month ago                                       │  ║
║ │                                                             │  ║
║ │  "Perfect for working professionals"                        │  ║
║ │                                                             │  ║
║ │  Monday evening time works great for my schedule. The       │  ║
║ │  group is welcoming to all skill levels and the course is  │  ║
║ │  always in excellent condition.                             │  ║
║ │                                                             │  ║
║ │  Helpful? 👍 8  👎 0                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  [Avatar] David P.                             ⭐⭐⭐⭐        │  ║
║ │           Handicap 9.8 • Verified Member                    │  ║
║ │           1 month ago                                       │  ║
║ │                                                             │  ║
║ │  "Good value"                                               │  ║
║ │                                                             │  ║
║ │  Pricing is fair for what you get. Course is in great      │  ║
║ │  shape. Only wish there were more social events during     │  ║
║ │  the season.                                                │  ║
║ │                                                             │  ║
║ │  Helpful? 👍 5  👎 1                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [Load More Reviews]                                              ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## User State Variations

### Anonymous Visitor
```
Hero CTA: [Register Now - $450] → Redirects to /login with return URL
Sticky bottom bar: "Join this league - Register or Sign in"
```

### Logged-In User (Not Registered)
```
Hero CTA: [Register Now - $450] → Opens registration modal/flow
Shows personalized messaging: "Hi Alex, join this league!"
```

### Logged-In User (Already Registered)
```
Hero section changes to:
┌─────────────────────────────────────────────────────────────┐
│  ✓ You're registered for this league!                      │
│                                                             │
│  Your Flight: Flight A                                      │
│  Next Match: Monday, Mar 3 at 5:30 PM                     │
│  Current Standing: 3rd of 8                                │
│                                                             │
│  [View My Stats] [Message Organizer] [Submit Score]       │
└─────────────────────────────────────────────────────────────┘
```

### League Organizer/Admin
```
Additional admin bar at top:
┌─────────────────────────────────────────────────────────────┐
│  🛠️ League Admin Tools                                      │
│  [Edit League] [Manage Roster] [Post Announcement]         │
│  [View Registrations] [Financial Reports]                  │
└─────────────────────────────────────────────────────────────┘
```

---

## Registration Flow (Modal/Page)

### Step 1: Choose Payment Option
```
╔═══════════════════════════════════════════════════════════════╗
║  REGISTER FOR MONDAY NIGHT GOLF LEAGUE                        ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Choose your payment option:                                  ║
║                                                               ║
║  ⚪ Full Payment ($450)                                       ║
║     Pay now and you're all set                               ║
║                                                               ║
║  ⚪ Early Bird Special ($400) 💰                              ║
║     Available until Jan 15                                    ║
║                                                               ║
║  ⚪ Payment Plan (3 × $160)                                   ║
║     $480 total (small processing fee)                        ║
║     Auto-charged monthly                                      ║
║                                                               ║
║  [Continue to Payment]                                        ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

### Step 2: Confirm Details
```
╔═══════════════════════════════════════════════════════════════╗
║  CONFIRM YOUR INFORMATION                                     ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Personal Information:                                        ║
║  Name: Alex Martinez                                          ║
║  Email: alex@example.com                                      ║
║  Phone: (555) 123-4567                                       ║
║  [Edit]                                                       ║
║                                                               ║
║  Golf Information:                                            ║
║  GHIN Number: [Enter your GHIN]                              ║
║  Current Handicap: [Auto-filled from GHIN]                   ║
║                                                               ║
║  Emergency Contact:                                           ║
║  Name: [Enter name]                                           ║
║  Phone: [Enter phone]                                        ║
║                                                               ║
║  ☑️ I agree to the league rules and waiver                    ║
║  ☑️ I commit to playing all 12 weeks                         ║
║                                                               ║
║  [Back] [Continue to Payment]                                ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

### Step 3: Payment (Stripe Checkout)
```
╔═══════════════════════════════════════════════════════════════╗
║  PAYMENT                                                      ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Order Summary:                                               ║
║  Monday Night Golf League                    $450.00         ║
║  Processing Fee                              $  0.00         ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                   ║
║  Total:                                      $450.00         ║
║                                                               ║
║  [Embedded Stripe Payment Form]                               ║
║                                                               ║
║  🔒 Secure payment powered by Stripe                         ║
║                                                               ║
║  [Back] [Complete Registration]                              ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## Success States

### Registration Success
```
╔═══════════════════════════════════════════════════════════════╗
║  ✅ YOU'RE REGISTERED!                                        ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Welcome to Monday Night Golf League!                         ║
║                                                               ║
║  What's Next:                                                 ║
║  1. Check your email for confirmation and league details     ║
║  2. You'll be assigned to a flight based on handicap         ║
║  3. First round is Monday, Feb 3 at 5:30 PM                  ║
║                                                               ║
║  [View League Details] [Add to Calendar] [Done]              ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

### Waitlist Added
```
╔═══════════════════════════════════════════════════════════════╗
║  ADDED TO WAITLIST                                            ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  This league is currently full.                              ║
║                                                               ║
║  You're #3 on the waitlist.                                  ║
║                                                               ║
║  We'll email you if a spot opens up!                         ║
║                                                               ║
║  [Browse Similar Leagues] [Done]                             ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## Error States

### League Full
```
╔═══════════════════════════════════════════════════════════════╗
║  ⚠️ LEAGUE FULL                                              ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  This league has reached capacity (32/32 players).           ║
║                                                               ║
║  Options:                                                     ║
║  • Join the waitlist (3 people ahead of you)                ║
║  • Browse similar leagues at this venue                      ║
║  • Get notified about future seasons                         ║
║                                                               ║
║  [Join Waitlist] [Find Similar Leagues]                      ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

### Registration Closed
```
╔═══════════════════════════════════════════════════════════════╗
║  REGISTRATION CLOSED                                          ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Registration for this league closed on Jan 30, 2025.        ║
║                                                               ║
║  The season is currently in progress (Week 4 of 12).         ║
║                                                               ║
║  What you can do:                                             ║
║  • Follow this league to get notified about next season     ║
║  • Browse other leagues at Desert Ridge Golf Club            ║
║  • Find leagues with open registration                       ║
║                                                               ║
║  [Follow League] [Find Other Leagues]                        ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

### Payment Failed
```
╔═══════════════════════════════════════════════════════════════╗
║  ❌ PAYMENT FAILED                                            ║
╠═══════════════════════════════════════════════════════════════╣
║                                                               ║
║  Your payment could not be processed.                         ║
║                                                               ║
║  Error: Card declined                                         ║
║                                                               ║
║  Please try:                                                  ║
║  • Using a different payment method                          ║
║  • Checking with your bank                                   ║
║  • Contacting support if the problem persists               ║
║                                                               ║
║  [Try Again] [Use Different Card] [Contact Support]          ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## Mobile Optimization

### Mobile Hero (Collapsed)
```
┌───────────────────────────────┐
│ 🏌️ Monday Night Golf League  │
│                               │
│ Desert Ridge Golf Club        │
│ ⭐ 4.8 • 28/32 • $450         │
│                               │
│ [Register Now]                │
│ Only 4 spots left!            │
│                               │
│ [Gallery - swipeable]         │
└───────────────────────────────┘
```

### Mobile Tabs (Horizontal Scroll)
```
┌──────────────────────────────────────┐
│ [Overview] [Schedule] [Standings] → │
└──────────────────────────────────────┘
```

### Sticky Mobile CTA
```
┌───────────────────────────────┐
│ $450 • 4 spots left          │
│ [Register Now]                │
└───────────────────────────────┘
```

---

## Key Interactions & Behaviors

### On Page Load
1. Check user authentication status
2. Check registration status for this league
3. Fetch league data (overview, stats, schedule)
4. Show appropriate hero CTA based on user state
5. Track page view in analytics

### Follow/Unfollow
- Toggle follow status
- Update notification preferences
- Show confirmation toast
- Update follow count

### Share League
- Generate shareable link
- Copy to clipboard
- Share via social (Twitter, Facebook, WhatsApp)
- Track share in analytics

### Register Button Click
- If anonymous: redirect to /login?return_to=/leagues/{id}
- If logged in: open registration modal
- If already registered: scroll to "Your Registration" section
- If league full: show waitlist option

### Add to Calendar
- Generate ICS file with all league dates
- Download to user's device
- Works for individual weeks or entire season

---

## API Integration Points

**GET `/leagues/{id}`**
- Fetch league details
- Include related data (venue, organizer, stats)
- Return registration status for current user

**GET `/leagues/{id}/schedule`**
- Fetch season schedule
- Include pairings if available

**GET `/leagues/{id}/standings`**
- Fetch current standings
- Include recent results

**GET `/leagues/{id}/roster`**
- Fetch registered players
- Group by flight/team

**GET `/leagues/{id}/reviews`**
- Fetch player reviews
- Paginated results

**POST `/leagues/{id}/register`**
- Initiate registration
- Create checkout session
- Return Stripe URL

**POST `/leagues/{id}/follow`**
- Toggle follow status
- Update notification preferences

**POST `/leagues/{id}/waitlist`**
- Add user to waitlist
- Send confirmation email

---

## SEO & Metadata

**Title:**
`{League Name} - {Sport} League at {Venue} | The League`

**Description:**
`Join {League Name}, a {sport} league at {Venue}. {Day} at {Time}. {Participants} players, {Skill Level}. Register now for ${Price}.`

**Structured Data (JSON-LD):**
```json
{
  "@type": "SportsEvent",
  "name": "Monday Night Golf League",
  "sport": "Golf",
  "location": {
    "@type": "Place",
    "name": "Desert Ridge Golf Club"
  },
  "startDate": "2025-02-03",
  "offers": {
    "@type": "Offer",
    "price": "450",
    "priceCurrency": "USD"
  }
}
```

---

## Analytics Events to Track

- Page view
- Tab switch (Overview → Schedule, etc.)
- Register button click
- Payment initiated
- Payment completed
- Follow/unfollow
- Share link generated
- Review submitted
- Waitlist joined
- External link clicks (venue profile, directions)

---

This wireframe provides the complete league detail page structure with all necessary states, user flows, and integration points. Should I create the companion wireframes for:

1. **Payment flow pages** (`/payment/success`, `/payment/cancel`)
2. **Venue detail page** (`/venues/[id]`)
3. **Tournament detail page** (`/tournaments/[id]`)

Or would you like me to refine any section of this wireframe first?
