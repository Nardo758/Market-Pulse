# Tournament Detail Page Wireframe
## `/tournaments/[id]` - Physical & Online Tournaments

---

## Page Overview

**Purpose:** 
- Display tournament information and bracket
- Enable registration and payment
- Show live results and standings
- Manage tournament progression

**URL Pattern:** `/tournaments/{tournament_id}`

**Tournament Types:**
- **Physical:** Golf, Pickleball, Bowling, Softball, Tennis, Soccer tournaments
- **Online:** Connect4, Chess, Checkers, Battleship game tournaments

**User States:**
- Anonymous visitor
- Logged-in user (not registered)
- Registered participant
- Tournament organizer/admin
- Spectator (for online games)

**Key Actions:**
- Register/enter tournament
- View bracket
- Check schedule
- See results
- Report match results (participants)
- Follow tournament updates
- **[Online]** Watch live matches

---

## Full Page Wireframe - Physical Tournament

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Logo] The League     [Search]  [Discover] [My Leagues] [Profile]║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ← Back to Tournaments / Venue / Channel                          ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │                    HERO SECTION                             │  ║
║ │                                                             │  ║
║ │  [Tournament Banner Image - 1200x400]                       │  ║
║ │  ┌──────────────────────────────────────────────────────┐   │  ║
║ │  │                                                      │   │  ║
║ │  │  [Gradient overlay]                                 │   │  ║
║ │  │                                                      │   │  ║
║ │  │  🏆 Spring Championship                             │   │  ║
║ │  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                      │   │  ║
║ │  │                                                      │   │  ║
║ │  │  🏌️ Golf • 4-Person Scramble                        │   │  ║
║ │  │  📍 Desert Ridge Golf Club                          │   │  ║
║ │  │  📅 Saturday, March 15, 2025 • 7:00 AM              │   │  ║
║ │  │                                                      │   │  ║
║ │  └──────────────────────────────────────────────────────┘   │  ║
║ │                                                             │  ║
║ │  STATUS: 🔴 REGISTRATION OPEN                               │  ║
║ │  👥 64/128 players (16/32 teams) • 💰 $500/team             │  ║
║ │  🏆 $5,000 prize pool • ⭐ Open to all skill levels         │  ║
║ │  ⏰ Early bird pricing ends Feb 15 - Save $50!              │  ║
║ │                                                             │  ║
║ │  ┌────────────────┐  ┌───────────────┐  ┌──────────────┐  │  ║
║ │  │ Register Team  │  │ ⭐ Follow     │  │ 🔗 Share     │  │  ║
║ │  │ $500 ($450EB)  │  │ 342 followers │  │              │  │  ║
║ │  └────────────────┘  └───────────────┘  └──────────────┘  │  ║
║ │                                                             │  ║
║ │  📢 Registration closes March 10 or when full              │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║           TAB NAVIGATION                                          ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                   ║
║  [Overview] [Bracket] [Participants] [Schedule] [Rules] [Results]║
║   ━━━━━━━━                                                        ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║                    OVERVIEW TAB CONTENT                           ║
║                                                                   ║
║ ┌───────────────────────────────┬─────────────────────────────┐  ║
║ │  TOURNAMENT DETAILS           │  QUICK INFO                 │  ║
║ │                               │                             │  ║
║ │  Join us for the Spring       │  ┌─────────────────────┐   │  ║
║ │  Championship, our premier    │  │  📊 STATUS          │   │  ║
║ │  annual golf tournament!      │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │                               │  │                     │   │  ║
║ │  This 4-person scramble       │  │  🔴 Registration    │   │  ║
║ │  tournament brings together   │  │     Open            │   │  ║
║ │  the best amateur golfers in  │  │                     │   │  ║
║ │  the Phoenix area for a day   │  │  Closes: Mar 10     │   │  ║
║ │  of competitive fun.          │  │  or when full       │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ │  Tournament Format:           │                             │  ║
║ │  • 4-person scramble          │  ┌─────────────────────┐   │  ║
║ │  • 18 holes, shotgun start    │  │  👥 CAPACITY        │   │  ║
║ │  • Championship Course        │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  • Net scoring with handicaps │  │                     │   │  ║
║ │                               │  │  Teams: 16/32       │   │  ║
║ │  What's Included:             │  │  Players: 64/128    │   │  ║
║ │  ✓ 18 holes with cart         │  │                     │   │  ║
║ │  ✓ Breakfast before round     │  │  50% Full           │   │  ║
║ │  ✓ Lunch after play           │  │  ████████░░░░░░░    │   │  ║
║ │  ✓ Range balls                │  └─────────────────────┘   │  ║
║ │  ✓ Goodie bag                 │                             │  ║
║ │  ✓ Awards ceremony            │  ┌─────────────────────┐   │  ║
║ │  ✓ Prizes for top 5 teams     │  │  💵 PRICING         │   │  ║
║ │  ✓ Contest prizes             │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │    (closest to pin, long      │  │                     │   │  ║
║ │    drive, hole-in-one)        │  │  Regular: $500/team │   │  ║
║ │                               │  │  Early Bird: $450   │   │  ║
║ │  Prize Breakdown:             │  │  (until Feb 15)     │   │  ║
║ │  🥇 1st Place: $2,000         │  │                     │   │  ║
║ │  🥈 2nd Place: $1,200         │  │  = $125/player      │   │  ║
║ │  🥉 3rd Place: $800           │  │  (early bird)       │   │  ║
║ │     4th Place: $500           │  │                     │   │  ║
║ │     5th Place: $300           │  │  Max 4 per team     │   │  ║
║ │  Plus contest prizes          │  └─────────────────────┘   │  ║
║ │                               │                             │  ║
║ │  Requirements:                │  ┌─────────────────────┐   │  ║
║ │  • Teams of 4 players         │  │  🏆 PRIZE POOL      │   │  ║
║ │  • All skill levels welcome   │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │  • Valid handicap recommended │  │                     │   │  ║
║ │  • Age 18+                    │  │  Total: $5,000      │   │  ║
║ │                               │  │                     │   │  ║
║ │                               │  │  Funded by entry    │   │  ║
║ │                               │  │  fees + sponsors    │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ └───────────────────────────────┴─────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📅 TOURNAMENT SCHEDULE                                     │  ║
║ │                                                             │  ║
║ │  Saturday, March 15, 2025                                   │  ║
║ │                                                             │  ║
║ │  6:00 AM - Registration & check-in opens                    │  ║
║ │  6:30 AM - Breakfast service begins                         │  ║
║ │  6:45 AM - Rules meeting & team photos                      │  ║
║ │  7:00 AM - Shotgun start (all teams tee off)               │  ║
║ │  11:30 AM - Expected finish time                            │  ║
║ │  12:00 PM - Lunch service begins                            │  ║
║ │  12:30 PM - Awards ceremony                                 │  ║
║ │  1:30 PM - Event concludes                                  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏢 VENUE INFORMATION                                       │  ║
║ │                                                             │  ║
║ │  📍 Desert Ridge Golf Club                                  │  ║
║ │  Championship Course                                        │  ║
║ │  5594 E Clubhouse Dr, Phoenix, AZ 85054                    │  ║
║ │                                                             │  ║
║ │  Course Details:                                            │  ║
║ │  • Par: 72 • Length: 7,002 yards                           │  ║
║ │  • Rating: 73.8 / Slope: 142                               │  ║
║ │                                                             │  ║
║ │  [View Venue] [Get Directions]                              │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  👤 TOURNAMENT DIRECTOR                                     │  ║
║ │                                                             │  ║
║ │  [Photo] Sarah Chen                                         │  ║
║ │          Head Golf Professional                             │  ║
║ │          Desert Ridge Golf Club                             │  ║
║ │          📧 sarah.chen@desertridge.com                      │  ║
║ │          📞 (480) 333-3335                                  │  ║
║ │                                                             │  ║
║ │  [Contact Organizer]                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🤝 SPONSORS                                                │  ║
║ │                                                             │  ║
║ │  Title Sponsor: [TaylorMade Logo]                           │  ║
║ │  Hole Sponsors: [Logos of 18 hole sponsors]                │  ║
║ │  Contest Sponsors: [Logos]                                  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📝 REGISTRATION REQUIREMENTS                               │  ║
║ │                                                             │  ║
║ │  To register your team:                                     │  ║
║ │  1. Team captain creates team profile                       │  ║
║ │  2. Add 3 additional team members (min 4, max 4)           │  ║
║ │  3. Submit team handicaps (optional but recommended)        │  ║
║ │  4. Complete payment ($500 or $450 early bird)             │  ║
║ │  5. Sign waiver and tournament rules agreement              │  ║
║ │                                                             │  ║
║ │  Payment accepted via credit card (Stripe)                  │  ║
║ │                                                             │  ║
║ │  Cancellation Policy:                                       │  ║
║ │  • Full refund until Feb 28                                │  ║
║ │  • 50% refund until Mar 7                                  │  ║
║ │  • No refunds after Mar 7                                  │  ║
║ │  • Weather cancellation: full refund                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  PAST TOURNAMENTS                                           │  ║
║ │                                                             │  ║
║ │  ┌──────────────┬──────────────┬──────────────┐            │  ║
║ │  │ Spring 2024  │ Fall 2023    │ Spring 2023  │            │  ║
║ │  │ 32 teams     │ 28 teams     │ 30 teams     │            │  ║
║ │  │ Winner: -18  │ Winner: -16  │ Winner: -19  │            │  ║
║ │  │ View Results │ View Results │ View Results │            │  ║
║ │  └──────────────┴──────────────┴──────────────┘            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Bracket Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Bracket] [Participants] [Schedule] [Rules] [Results]║
║             ━━━━━━━━                                              ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  TOURNAMENT BRACKET                                               ║
║                                                                   ║
║  Format: Single Elimination (after shotgun round)                 ║
║  Top 8 teams advance to playoff bracket                           ║
║                                                                   ║
║  ⚠️ Bracket will be available after shotgun round scoring        ║
║     is complete (approx. 12:00 PM on March 15)                    ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  PROJECTED BRACKET (Based on current registrations)         │  ║
║ │                                                             │  ║
║ │  QUARTERFINALS    SEMIFINALS       FINAL        CHAMPION    │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  #1 Seed ────┐                                              │  ║
║ │              ├─────── TBD ────┐                             │  ║
║ │  #8 Seed ────┘                │                             │  ║
║ │                               ├───── TBD ────┐              │  ║
║ │  #4 Seed ────┐                │              │              │  ║
║ │              ├─────── TBD ────┘              │              │  ║
║ │  #5 Seed ────┘                               │              │  ║
║ │                                              ├────── 🏆     │  ║
║ │  #2 Seed ────┐                               │              │  ║
║ │              ├─────── TBD ────┐              │              │  ║
║ │  #7 Seed ────┘                │              │              │  ║
║ │                               ├───── TBD ────┘              │  ║
║ │  #3 Seed ────┐                │                             │  ║
║ │              ├─────── TBD ────┘                             │  ║
║ │  #6 Seed ────┘                                              │  ║
║ │                                                             │  ║
║ │  Note: Seeding determined by shotgun round net scores       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💡 HOW IT WORKS                                            │  ║
║ │                                                             │  ║
║ │  Phase 1: Shotgun Round (7:00 AM - 11:30 AM)               │  ║
║ │  • All 32 teams play 18 holes                               │  ║
║ │  • Net scoring with handicaps                               │  ║
║ │  • Teams ranked by net score                                │  ║
║ │                                                             │  ║
║ │  Phase 2: Playoff Bracket (if applicable)                   │  ║
║ │  • Top 8 teams advance to playoffs                          │  ║
║ │  • Match play format (hole-by-hole)                         │  ║
║ │  • Championship determined by playoffs                      │  ║
║ │                                                             │  ║
║ │  If no playoffs: Winner determined by shotgun round         │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Participants Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Bracket] [Participants] [Schedule] [Rules] [Results]║
║                      ━━━━━━━━━━━━━                                ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  REGISTERED TEAMS                                                 ║
║                                                                   ║
║  16 Teams Registered • 64 Players • 16 Spots Remaining            ║
║                                                                   ║
║  [Search Teams...] | Sort: [Registration Date] [Team Name] [Avg Hdcp] ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  Team 1: The Birdies                           Reg #001      │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  Team Captain: Mike Thompson (Hdcp 8.2)                     │  ║
║ │  Members:                                                   │  ║
║ │  • Sarah Chen (Hdcp 9.5)                                    │  ║
║ │  • John Martinez (Hdcp 7.8)                                 │  ║
║ │  • Lisa Anderson (Hdcp 10.1)                                │  ║
║ │                                                             │  ║
║ │  Team Average Handicap: 8.9                                 │  ║
║ │  Registered: Jan 15, 2025 (Early Bird)                      │  ║
║ │                                                             │  ║
║ │  [View Team Profile]                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  Team 2: Eagle Hunters                         Reg #002      │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  Team Captain: David Park (Hdcp 8.9)                        │  ║
║ │  Members:                                                   │  ║
║ │  • Jennifer Wu (Hdcp 9.2)                                   │  ║
║ │  • Robert Lee (Hdcp 8.5)                                    │  ║
║ │  • Maria Garcia (Hdcp 9.8)                                  │  ║
║ │                                                             │  ║
║ │  Team Average Handicap: 9.1                                 │  ║
║ │  Registered: Jan 20, 2025 (Early Bird)                      │  ║
║ │                                                             │  ║
║ │  [View Team Profile]                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [... 14 more teams ...]                                          ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💡 WANT TO JOIN?                                           │  ║
║ │                                                             │  ║
║ │  16 team spots still available!                             │  ║
║ │                                                             │  ║
║ │  Options:                                                   │  ║
║ │  • Register your own team (need 4 players)                  │  ║
║ │  • Join as individual (we'll match you with a team)        │  ║
║ │  • Post in tournament forum to find teammates               │  ║
║ │                                                             │  ║
║ │  [Register Team] [Join as Individual] [Find Teammates]     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Schedule Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Bracket] [Participants] [Schedule] [Rules] [Results]║
║                                     ━━━━━━━━                      ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  TOURNAMENT SCHEDULE                                              ║
║                                                                   ║
║  Saturday, March 15, 2025                                         ║
║  Desert Ridge Golf Club - Championship Course                     ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  DETAILED TIMELINE                                          │  ║
║ │                                                             │  ║
║ │  6:00 AM - Registration & Check-In Opens                    │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Check in at the golf shop                                  │  ║
║ │  • Verify team roster                                       │  ║
║ │  • Receive scorecards and goodie bags                       │  ║
║ │  • Get cart assignments                                     │  ║
║ │                                                             │  ║
║ │  6:30 AM - Breakfast Service Begins                         │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Clubhouse restaurant                                       │  ║
║ │  • Continental breakfast buffet                             │  ║
║ │  • Coffee, juice, pastries                                  │  ║
║ │                                                             │  ║
║ │  6:30 AM - Practice Facilities Open                         │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  • Driving range (range balls provided)                     │  ║
║ │  • Putting greens                                           │  ║
║ │  • Chipping area                                            │  ║
║ │                                                             │  ║
║ │  6:45 AM - Rules Meeting & Team Photos                      │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Clubhouse patio                                            │  ║
║ │  • Tournament director welcome                              │  ║
║ │  • Rules and format explanation                             │  ║
║ │  • Team photos                                              │  ║
║ │  • Q&A                                                      │  ║
║ │                                                             │  ║
║ │  7:00 AM - SHOTGUN START                                    │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  All teams tee off simultaneously                           │  ║
║ │  • Teams assigned to specific holes                         │  ║
║ │  • Air horn signals start                                   │  ║
║ │  • Play 18 holes in scramble format                         │  ║
║ │  • Estimated time: 4.5 hours                                │  ║
║ │                                                             │  ║
║ │  11:30 AM - Expected Finish Time                            │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  • Return to clubhouse                                      │  ║
║ │  • Submit scorecards at golf shop                           │  ║
║ │  • Scoring verification                                     │  ║
║ │                                                             │  ║
║ │  12:00 PM - Lunch Service Begins                            │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Clubhouse restaurant                                       │  ║
║ │  • Buffet lunch                                             │  ║
║ │  • Cash bar available                                       │  ║
║ │                                                             │  ║
║ │  12:30 PM - Awards Ceremony                                 │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Clubhouse patio                                            │  ║
║ │  • Announce contest winners (closest to pin, long drive)   │  ║
║ │  • Team awards (1st through 5th place)                      │  ║
║ │  • Prize distribution                                       │  ║
║ │  • Photos with trophies                                     │  ║
║ │                                                             │  ║
║ │  1:30 PM - Event Concludes                                  │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  SHOTGUN START ASSIGNMENTS                                  │  ║
║ │  (Posted 2 days before tournament)                          │  ║
║ │                                                             │  ║
║ │  Hole 1: Team TBD                                           │  ║
║ │  Hole 2: Team TBD                                           │  ║
║ │  Hole 3: Team TBD                                           │  ║
║ │  ... [assignments for all holes] ...                        │  ║
║ │                                                             │  ║
║ │  ⚠️ Check back on March 13 for hole assignments            ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📅 ADD TO CALENDAR                                         │  ║
║ │                                                             │  ║
║ │  [Download ICS File] [Google Calendar] [Outlook]           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Rules Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Bracket] [Participants] [Schedule] [Rules] [Results]║
║                                               ━━━━━                ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  TOURNAMENT RULES                                                 ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  FORMAT                                                     │  ║
║ │                                                             │  ║
║ │  4-Person Scramble                                          │  ║
║ │  • All 4 players tee off                                    │  ║
║ │  • Team selects best drive                                  │  ║
║ │  • All players hit from that spot                           │  ║
║ │  • Continue until ball is holed                             │  ║
║ │  • Record team score for each hole                          │  ║
║ │                                                             │  ║
║ │  Shotgun Start                                              │  ║
║ │  • All teams start simultaneously at 7:00 AM                │  ║
║ │  • Each team assigned to a starting hole (1-18)            │  ║
║ │  • Play holes in order from starting position               │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  SCORING                                                    │  ║
║ │                                                             │  ║
║ │  Gross vs Net                                               │  ║
║ │  • Both gross and net scores recorded                       │  ║
║ │  • Prizes awarded based on NET scores                       │  ║
║ │  • Gross scores used for bragging rights                    │  ║
║ │                                                             │  ║
║ │  Handicap System                                            │  ║
║ │  • Team handicap = 25% of combined individual handicaps    │  ║
║ │  • Example: Team hdcp (8+9+10+11) = 38 × 0.25 = 9.5        │  ║
║ │  • Rounded to nearest whole number                          │  ║
║ │  • Maximum team handicap: 12                                │  ║
║ │                                                             │  ║
║ │  Score Verification                                         │  ║
║ │  • Both teams on same hole verify each other's scores      │  ║
║ │  • Scorecards signed by playing partner                     │  ║
║ │  • Submitted to golf shop immediately after play            │  ║
║ │  • Disputes resolved by tournament director                 │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  PLAYER REQUIREMENTS                                        │  ║
║ │                                                             │  ║
║ │  Team Composition                                           │  ║
║ │  • Minimum 4 players, maximum 4 players                     │  ║
║ │  • All team members must be 18+                            │  ║
║ │  • Substitutions allowed until March 10                     │  ║
║ │  • No substitutions after registration closes               │  ║
║ │                                                             │  ║
║ │  Handicaps                                                  │  ║
║ │  • GHIN handicap recommended but not required               │  ║
║ │  • Self-reported handicaps accepted                         │  ║
║ │  • Tournament director may adjust suspicious handicaps      │  ║
║ │  • No handicap? Use your average score - par               │  ║
║ │                                                             │  ║
║ │  Equipment                                                  │  ║
║ │  • Own clubs required                                       │  ║
║ │  • Rental clubs available at golf shop ($50)               │  ║
║ │  • Golf carts included in entry fee                         │  ║
║ │  • Push carts not permitted (pace of play)                  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  RULES OF PLAY                                              │  ║
║ │                                                             │  ║
║ │  USGA Rules Apply                                           │  ║
║ │  • Modified for scramble format                             │  ║
║ │  • Tournament director has final say                        │  ║
║ │                                                             │  ║
║ │  Scramble-Specific Rules                                    │  ║
║ │  • Minimum drive requirement: Each player's drive must be  │  ║
║ │    used at least 3 times during round                       │  ║
║ │  • When in bunker, if team selects shot from bunker, at    │  ║
║ │    least 1 player must hit from bunker                      │  ║
║ │  • Putts: At least 2 different players must make putts     │  ║
║ │    that count toward team score                             │  ║
║ │                                                             │  ║
║ │  Pace of Play                                               │  ║
║ │  • Target pace: 4 hours 30 minutes                         │  ║
║ │  • Keep up with group ahead                                 │  ║
║ │  • Ready golf encouraged                                    │  ║
║ │  • Warning for slow play, stroke penalty if excessive      │  ║
║ │                                                             │  ║
║ │  Out of Bounds / Lost Ball                                  │  ║
║ │  • Stroke and distance penalty                              │  ║
║ │  • Drop zone available on select holes                      │  ║
║ │  • 3-minute search limit                                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  CONTEST HOLES                                              │  ║
║ │                                                             │  ║
║ │  Closest to the Pin                                         │  ║
║ │  • Holes: 3, 8, 12, 16 (all par 3s)                        │  ║
║ │  • Tee shot must land on green and stay on green           │  ║
║ │  • Measured from pin                                        │  ║
║ │  • Prize: $100 each hole                                    │  ║
║ │                                                             │  ║
║ │  Longest Drive                                              │  ║
║ │  • Holes: 5, 14 (designated long par 4s/5s)                │  ║
║ │  • Must land in fairway                                     │  ║
║ │  • Prize: $100 each hole                                    │  ║
║ │                                                             │  ║
║ │  Hole-in-One                                                │  ║
║ │  • Any par 3 (holes 3, 8, 12, 16)                          │  ║
║ │  • Prize: $1,000 cash (sponsored)                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  CONDUCT & ETIQUETTE                                        │  ║
║ │                                                             │  ║
║ │  Dress Code                                                 │  ║
║ │  • Collared shirts required (no t-shirts)                   │  ║
║ │  • Golf shorts or pants (no jeans)                          │  ║
║ │  • Golf shoes required (soft spikes or spikeless)          │  ║
║ │                                                             │  ║
║ │  Behavior                                                   │  ║
║ │  • Respect other players and course                         │  ║
║ │  • Repair ball marks and divots                             │  ║
║ │  • Rake bunkers                                             │  ║
║ │  • No alcohol on course (available after play)             │  ║
║ │  • Cell phones on silent                                    │  ║
║ │                                                             │  ║
║ │  Violations                                                 │  ║
║ │  • First offense: Warning                                   │  ║
║ │  • Second offense: 2-stroke penalty                         │  ║
║ │  • Serious offense: Disqualification                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  WEATHER & CANCELLATION                                     │  ║
║ │                                                             │  ║
║ │  Weather Policy                                             │  ║
║ │  • Tournament proceeds rain or shine unless unsafe          │  ║
║ │  • Lightning: Play suspended, resume when safe              │  ║
║ │  • Course unplayable: Tournament rescheduled                │  ║
║ │                                                             │  ║
║ │  Cancellation Notice                                        │  ║
║ │  • Decision by 6:00 AM day of tournament                   │  ║
║ │  • Notification via email, text, and phone                  │  ║
║ │  • Check tournament page for updates                        │  ║
║ │                                                             │  ║
║ │  Refund Policy (Weather)                                    │  ║
║ │  • Full refund if tournament cancelled                      │  ║
║ │  • Credit toward rescheduled date                           │  ║
║ │  • No refund if tournament starts then suspended            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  WAIVER & LIABILITY                                         │  ║
║ │                                                             │  ║
║ │  All participants must sign waiver acknowledging:           │  ║
║ │  • Golf is a potentially hazardous activity                 │  ║
║ │  • Participant assumes all risks                            │  ║
║ │  • Release of liability for organizers and venue            │  ║
║ │  • Agreement to follow all rules                            │  ║
║ │                                                             │  ║
║ │  [View Full Waiver] [Download PDF]                          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Results Tab (Post-Tournament)

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Overview] [Bracket] [Participants] [Schedule] [Rules] [Results]║
║                                                         ━━━━━━━━  ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  TOURNAMENT RESULTS                                               ║
║                                                                   ║
║  Spring Championship • March 15, 2025                             ║
║  32 Teams • 128 Players • Desert Ridge Golf Club                  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 FINAL STANDINGS                                         │  ║
║ │                                                             │  ║
║ │  Rank | Team Name        | Gross | Net | Prize             │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  🥇 1  | The Birdies      |  61   | 52  | $2,000           │  ║
║ │  🥈 2  | Eagle Hunters    |  63   | 54  | $1,200           │  ║
║ │  🥉 3  | Par Busters      |  64   | 55  | $800             │  ║
║ │     4  | Fairway Friends  |  65   | 55  | $500             │  ║
║ │     5  | Hole in Fun      |  66   | 56  | $300             │  ║
║ │     6  | Drive Time       |  67   | 57  | -                │  ║
║ │     7  | Tee Masters      |  68   | 58  | -                │  ║
║ │     8  | Green Machine    |  69   | 58  | -                │  ║
║ │     9  | Chip Shots       |  69   | 59  | -                │  ║
║ │    10  | Sand Trap        |  70   | 59  | -                │  ║
║ │                                                             │  ║
║ │  [View Full Standings (All 32 Teams)]                       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🎯 CONTEST WINNERS                                         │  ║
║ │                                                             │  ║
║ │  Closest to the Pin                                         │  ║
║ │  • Hole 3: Sarah Chen - 2'4" ($100)                        │  ║
║ │  • Hole 8: Mike Thompson - 3'1" ($100)                     │  ║
║ │  • Hole 12: David Park - 1'8" ($100)                       │  ║
║ │  • Hole 16: Jennifer Wu - 4'2" ($100)                      │  ║
║ │                                                             │  ║
║ │  Longest Drive                                              │  ║
║ │  • Hole 5: Robert Lee - 312 yards ($100)                   │  ║
║ │  • Hole 14: John Martinez - 295 yards ($100)               │  ║
║ │                                                             │  ║
║ │  Hole-in-One                                                │  ║
║ │  • None this tournament                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📊 TOURNAMENT STATISTICS                                   │  ║
║ │                                                             │  ║
║ │  Low Gross Score: 61 (The Birdies)                          │  ║
║ │  Low Net Score: 52 (The Birdies)                            │  ║
║ │  Average Gross Score: 68.4                                  │  ║
║ │  Average Net Score: 58.2                                    │  ║
║ │  Birdies: 287 total                                         │  ║
║ │  Eagles: 12 total                                           │  ║
║ │  Hole-in-Ones: 0                                            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📸 PHOTOS & VIDEOS                                         │  ║
║ │                                                             │  ║
║ │  [Photo Gallery - 156 photos]                               │  ║
║ │  • Team photos                                              │  ║
║ │  • Action shots                                             │  ║
║ │  • Awards ceremony                                          │  ║
║ │  • Contest winners                                          │  ║
║ │                                                             │  ║
║ │  [View All Photos]                                          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  💬 POST-TOURNAMENT FEEDBACK                                │  ║
║ │                                                             │  ║
║ │  Overall Rating: ⭐ 4.9 (Based on 28 reviews)               │  ║
║ │                                                             │  ║
║ │  "Best tournament we've played in! Great organization."     │  ║
║ │  - Mike Thompson (The Birdies)                              │  ║
║ │                                                             │  ║
║ │  "Course was in perfect condition. Will be back next year!" │  ║
║ │  - David Park (Eagle Hunters)                               │  ║
║ │                                                             │  ║
║ │  [View All Reviews] [Leave Your Review]                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📅 NEXT TOURNAMENT                                         │  ║
║ │                                                             │  ║
║ │  Fall Championship                                          │  ║
║ │  Saturday, September 20, 2025                               │  ║
║ │                                                             │  ║
║ │  Registration opens July 1                                  │  ║
║ │                                                             │  ║
║ │  [Get Notified] [Pre-Register Interest]                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Online Game Tournament Variant

```
╔═══════════════════════════════════════════════════════════════════╗
║  ONLINE CHESS TOURNAMENT - WINTER CHAMPIONSHIP                    ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  HERO SECTION                                               │  ║
║ │                                                             │  ║
║ │  ♟️ Winter Chess Championship                               │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                         │  ║
║ │                                                             │  ║
║ │  Online Chess Tournament                                    │  ║
║ │  January 10-25, 2025                                        │  ║
║ │                                                             │  ║
║ │  STATUS: 🟢 LIVE - Round 2 in Progress                      │  ║
║ │  👥 64/64 players • 💰 $500 prize pool • 🏆 ELO Rated       │  ║
║ │                                                             │  ║
║ │  ┌────────────────┐  ┌───────────────┐  ┌──────────────┐  │  ║
║ │  │ 🎮 Watch Live  │  │ ⭐ Follow     │  │ 🔗 Share     │  │  ║
║ │  │ 12 games now   │  │ Tournament    │  │              │  │  ║
║ │  └────────────────┘  └───────────────┘  └──────────────┘  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║  [Overview] [Bracket] [Live Games] [Standings] [Rules]           ║
║   ━━━━━━━━                                                        ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  TOURNAMENT DETAILS                                         │  ║
║ │                                                             │  ║
║ │  Format: Single Elimination                                 │  ║
║ │  Players: 64 (6 rounds to determine champion)               │  ║
║ │  Time Control: 10 minutes + 5 second increment              │  ║
║ │  Entry: Free (ELO rating 1200-1800)                        │  ║
║ │  Prize Pool: $500 (1st: $250, 2nd: $150, 3rd: $100)       │  ║
║ │                                                             │  ║
║ │  Schedule:                                                  │  ║
║ │  Round 1: Jan 10-12 ✅ Complete                             │  ║
║ │  Round 2: Jan 13-15 🟢 In Progress                          │  ║
║ │  Round 3: Jan 16-18                                         │  ║
║ │  Round 4: Jan 19-21                                         │  ║
║ │  Semifinals: Jan 22-23                                      │  ║
║ │  Finals: Jan 24-25                                          │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🎮 LIVE GAMES                                              │  ║
║ │                                                             │  ║
║ │  Round 2 - 12 games in progress                             │  ║
║ │                                                             │  ║
║ │  ♟️ Game 1: @ChessMaster vs @PawnStorm                      │  ║
║ │     Move 24 • White to move                                 │  ║
║ │     👁️ 245 watching                                         │  ║
║ │     [Watch Live]                                            │  ║
║ │                                                             │  ║
║ │  ♟️ Game 2: @QueenGambit vs @KnightRider                    │  ║
║ │     Move 18 • Black to move                                 │  ║
║ │     👁️ 178 watching                                         │  ║
║ │     [Watch Live]                                            │  ║
║ │                                                             │  ║
║ │  [View All Live Games]                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  BRACKET - SINGLE ELIMINATION                               │  ║
║ │                                                             │  ║
║ │  R1      R2         R3         R4       SF        FINAL     │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  P1 ✅──┐                                                    │  ║
║ │  P2 ❌  ├── P1 🟢                                            │  ║
║ │  P3 ✅──┤       │                                            │  ║
║ │  P4 ❌  └── P3  ├── TBD ─┐                                  │  ║
║ │  P5 ✅──┐       │        │                                   │  ║
║ │  P6 ❌  ├── P5 🟢        ├── TBD ─┐                          │  ║
║ │  P7 ✅──┤       │        │       │                           │  ║
║ │  P8 ❌  └── P7 ─┘        │       ├── TBD ─┐                 │  ║
║ │                          │       │        │                  │  ║
║ │  [... continues ...]     │       │        ├──── 🏆          │  ║
║ │                                  │        │                  │  ║
║ │  Legend:                         │        │                  │  ║
║ │  ✅ Complete  🟢 In Progress     │        │                  │  ║
║ │  ❌ Eliminated  TBD Upcoming      │        │                  │  ║
║ │                                          ─┘                  │  ║
║ │  [View Full Bracket]                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Registration Flow

### Step 1: Choose Team or Individual
```
╔═══════════════════════════════════════════════════════════════════╗
║  REGISTER FOR SPRING CHAMPIONSHIP                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  How would you like to register?                                  ║
║                                                                   ║
║  ⚪ Register Full Team (4 players)                                ║
║     You have all 4 players ready                                  ║
║     $500 total ($125/player with early bird)                      ║
║                                                                   ║
║  ⚪ Register as Individual                                        ║
║     We'll match you with other individual players                 ║
║     $125 (early bird pricing)                                     ║
║                                                                   ║
║  [Continue]                                                       ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

### Step 2: Team Information
```
╔═══════════════════════════════════════════════════════════════════╗
║  TEAM INFORMATION                                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Team Name: [Enter creative team name]                            ║
║                                                                   ║
║  Team Captain (you):                                              ║
║  Name: Alex Martinez                                              ║
║  Email: alex@example.com                                          ║
║  Phone: (555) 123-4567                                           ║
║  GHIN Number: [Optional]                                          ║
║  Handicap: [Enter handicap]                                       ║
║                                                                   ║
║  Team Member 2:                                                   ║
║  [Search existing user or enter new]                              ║
║  Email: [teammate2@example.com]                                   ║
║  Handicap: [Enter]                                                ║
║                                                                   ║
║  Team Member 3:                                                   ║
║  [Search existing user or enter new]                              ║
║  Email: [teammate3@example.com]                                   ║
║  Handicap: [Enter]                                                ║
║                                                                   ║
║  Team Member 4:                                                   ║
║  [Search existing user or enter new]                              ║
║  Email: [teammate4@example.com]                                   ║
║  Handicap: [Enter]                                                ║
║                                                                   ║
║  Team Average Handicap: [Auto-calculated]                         ║
║                                                                   ║
║  ☑️ I confirm all team members have agreed to participate         ║
║  ☑️ All team members are 18+ years old                           ║
║                                                                   ║
║  [Back] [Continue to Payment]                                     ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

### Step 3: Waiver & Payment
```
╔═══════════════════════════════════════════════════════════════════╗
║  WAIVER & PAYMENT                                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Order Summary:                                                   ║
║  Spring Championship - Team Registration                          ║
║  The Birdies (4 players)                      $450.00 ✅ Early   ║
║  Processing Fee                               $  0.00            ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║  Total:                                       $450.00            ║
║                                                                   ║
║  Waiver & Release:                                                ║
║  ☑️ I have read and agree to the tournament waiver                ║
║  ☑️ I agree to abide by all tournament rules                     ║
║  ☑️ I understand the cancellation policy                         ║
║                                                                   ║
║  [View Full Waiver]                                               ║
║                                                                   ║
║  [Embedded Stripe Payment Form]                                   ║
║                                                                   ║
║  🔒 Secure payment powered by Stripe                             ║
║                                                                   ║
║  [Back] [Complete Registration - $450]                            ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

This comprehensive wireframe covers both physical (golf) and online (chess) tournament formats. Next up: **Public Player Profile** (`/players/[id]`). Ready?

