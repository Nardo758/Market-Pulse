# Public Player Profile Page Wireframe
## `/players/[id]` or `/users/[id]` - Player Public Profile

---

## Page Overview

**Purpose:** 
- Display player's public profile and statistics
- Show participation history across sports
- Enable social connections (follow, message)
- Showcase achievements and progress

**URL Pattern:** `/players/{player_id}` or `/users/{user_id}`

**Visibility:**
- Public information (based on player's privacy settings)
- Different views for anonymous, logged-in, and profile owner

**User States:**
- Anonymous visitor (limited view)
- Logged-in user viewing someone else
- Player viewing own profile (full access + edit controls)

**Key Actions:**
- View player stats
- Follow/unfollow player
- Send message
- View shared leagues/connections
- Report inappropriate content
- **[Owner only]** Edit profile and privacy settings

---

## Full Page Wireframe

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Logo] The League     [Search]  [Discover] [My Leagues] [Profile]║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ← Back to League / Search / Previous Page                        ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │                    PROFILE HEADER                           │  ║
║ │                                                             │  ║
║ │  [Cover Photo - 1200x300px]                                 │  ║
║ │  ┌──────────────────────────────────────────────────────┐   │  ║
║ │  │                                                      │   │  ║
║ │  │  [Gradient overlay]                                 │   │  ║
║ │  │                                                      │   │  ║
║ │  │  ┌──────────┐                                       │   │  ║
║ │  │  │ [Avatar] │                                       │   │  ║
║ │  │  │  Photo   │                                       │   │  ║
║ │  │  │ 150x150  │                                       │   │  ║
║ │  │  └──────────┘                                       │   │  ║
║ │  │                                                      │   │  ║
║ │  └──────────────────────────────────────────────────────┘   │  ║
║ │                                                             │  ║
║ │  Alex Martinez                                              │  ║
║ │  ━━━━━━━━━━━━━━━━━━                                         │  ║
║ │  @alexm • 📍 Phoenix, AZ                                    │  ║
║ │  ⭐ Level 12 • 🏆 542 XP • 👥 234 followers • 189 following │  ║
║ │  🏌️ Golf • 🔴 Pickleball • 🎳 Bowling                      │  ║
║ │                                                             │  ║
║ │  "Weekend warrior. Always up for a round. Let's play!"      │  ║
║ │                                                             │  ║
║ │  ┌──────────────┐  ┌─────────────┐  ┌──────────────┐      │  ║
║ │  │ ⭐ Follow    │  │ 💬 Message  │  │ 🔗 Share     │      │  ║
║ │  │ Following    │  │             │  │              │      │  ║
║ │  └──────────────┘  └─────────────┘  └──────────────┘      │  ║
║ │                                                             │  ║
║ │  Member since: January 2022 • Last active: 2 hours ago     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  QUICK STATS                                                │  ║
║ │                                                             │  ║
║ │  ┌──────────────┬──────────────┬──────────────┬──────────┐ │  ║
║ │  │ 🏆 Leagues   │ 📊 Events    │ 🎯 Win Rate  │ 🔥 Streak│ │  ║
║ │  │ ━━━━━━━━━━━  │ ━━━━━━━━━━━  │ ━━━━━━━━━━━  │ ━━━━━━━━ │ │  ║
║ │  │              │              │              │          │ │  ║
║ │  │ 15 Total     │ 42 Played    │ 68%          │ 5 wins   │ │  ║
║ │  │ 3 Active     │ 8 Upcoming   │ 156-72-12    │ Current  │ │  ║
║ │  │              │              │              │          │ │  ║
║ │  └──────────────┴──────────────┴──────────────┴──────────┘ │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║           TAB NAVIGATION                                          ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ║
║                                                                   ║
║  [Activity] [Stats] [Leagues] [Achievements] [About]             ║
║   ━━━━━━━━                                                        ║
║                                                                   ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║                    ACTIVITY TAB CONTENT                           ║
║                                                                   ║
║ ┌───────────────────────────────┬─────────────────────────────┐  ║
║ │  RECENT ACTIVITY              │  SPORTS PLAYED              │  ║
║ │                               │                             │  ║
║ │  🏆 Placed 1st in Monday      │  ┌─────────────────────┐   │  ║
║ │     Night Golf League         │  │  🏌️ GOLF            │   │  ║
║ │     2 days ago                │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │                               │  │                     │   │  ║
║ │  ⭐ Achieved "Eagle Eye"      │  │  Handicap: 8.2      │   │  ║
║ │     badge                     │  │  Rounds: 124        │   │  ║
║ │     5 days ago                │  │  Best: 76           │   │  ║
║ │                               │  │  Avg: 84            │   │  ║
║ │  🎯 Posted score of 82 in     │  │                     │   │  ║
║ │     Monday Night Golf League  │  │  [View Golf Stats]  │   │  ║
║ │     1 week ago                │  └─────────────────────┘   │  ║
║ │                               │                             │  ║
║ │  🏅 Joined Wednesday Evening  │  ┌─────────────────────┐   │  ║
║ │     Scramble                  │  │  🔴 PICKLEBALL      │   │  ║
║ │     2 weeks ago               │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │                               │  │                     │   │  ║
║ │  🎳 Won team match in         │  │  Rating: 3.5        │   │  ║
║ │     Thursday Bowling League   │  │  Matches: 87        │   │  ║
║ │     3 weeks ago               │  │  Win Rate: 64%      │   │  ║
║ │                               │  │  Win/Loss: 56-31    │   │  ║
║ │  🔴 Advanced to Round 3 in    │  │                     │   │  ║
║ │     Pickleball Ladder         │  │  [View PB Stats]    │   │  ║
║ │     3 weeks ago               │  └─────────────────────┘   │  ║
║ │                               │                             │  ║
║ │  [Load More Activity]         │  ┌─────────────────────┐   │  ║
║ │                               │  │  🎳 BOWLING         │   │  ║
║ │                               │  │  ━━━━━━━━━━━━━━━━━  │   │  ║
║ │                               │  │                     │   │  ║
║ │                               │  │  Average: 178       │   │  ║
║ │                               │  │  Games: 216         │   │  ║
║ │                               │  │  High Game: 257     │   │  ║
║ │                               │  │  High Series: 689   │   │  ║
║ │                               │  │                     │   │  ║
║ │                               │  │  [View Stats]       │   │  ║
║ │                               │  └─────────────────────┘   │  ║
║ └───────────────────────────────┴─────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📸 RECENT PHOTOS                                           │  ║
║ │                                                             │  ║
║ │  [Photo Grid - 6 most recent photos]                        │  ║
║ │  • Winning team photo from Monday league                    │  ║
║ │  • Hole-in-one celebration                                  │  ║
║ │  • Tournament bracket advancement                           │  ║
║ │  • Team scramble action shot                                │  ║
║ │  • Awards ceremony                                          │  ║
║ │  • Casual round with friends                                │  ║
║ │                                                             │  ║
║ │  [View All Photos (142)]                                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Stats Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Activity] [Stats] [Leagues] [Achievements] [About]             ║
║             ━━━━━                                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  PLAYER STATISTICS                                                ║
║                                                                   ║
║  [Select Sport: Golf ▼] [Time Period: All Time ▼]                ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  ⛳ GOLF STATISTICS                                          │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │                                                             │  ║
║ │  Overall Performance                                        │  ║
║ │  ┌──────────────┬──────────────┬──────────────┬──────────┐ │  ║
║ │  │ Handicap     │ Rounds       │ Avg Score    │ Best     │ │  ║
║ │  │ ━━━━━━━━━━━  │ ━━━━━━━━━━━  │ ━━━━━━━━━━━  │ ━━━━━━━━ │ │  ║
║ │  │ 8.2          │ 124          │ 84           │ 76       │ │  ║
║ │  │ Improving ↓  │ This year    │ Last 20      │ Career   │ │  ║
║ │  └──────────────┴──────────────┴──────────────┴──────────┘ │  ║
║ │                                                             │  ║
║ │  Scoring Breakdown                                          │  ║
║ │  ┌──────────────┬──────────────┬──────────────┬──────────┐ │  ║
║ │  │ Eagles       │ Birdies      │ Pars         │ Bogeys+  │ │  ║
║ │  │ ━━━━━━━━━━━  │ ━━━━━━━━━━━  │ ━━━━━━━━━━━  │ ━━━━━━━━ │ │  ║
║ │  │ 12 (0.5%)    │ 287 (13%)    │ 892 (40%)    │ 1041     │ │  ║
║ │  └──────────────┴──────────────┴──────────────┴──────────┘ │  ║
║ │                                                             │  ║
║ │  Course Management                                          │  ║
║ │  Fairways Hit:    68% (842/1,240 opportunities)             │  ║
║ │  GIR:             52% (649/1,240 opportunities)             │  ║
║ │  Putts/Round:     32.4 average                              │  ║
║ │  Sand Saves:      41% (123/300 attempts)                    │  ║
║ │  Up & Downs:      38% (285/750 attempts)                    │  ║
║ │                                                             │  ║
║ │  League Performance                                         │  ║
║ │  Win Rate:        64% (32 wins, 18 losses, 4 ties)          │  ║
║ │  Podium Finishes: 12 (8 first, 3 second, 1 third)          │  ║
║ │  Tournaments:     8 entered, 3 top-10 finishes              │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📈 PERFORMANCE TRENDS                                      │  ║
║ │                                                             │  ║
║ │  [Line Graph: Handicap over time]                           │  ║
║ │  Shows improvement from 12.8 to 8.2 over 3 years            │  ║
║ │                                                             │  ║
║ │  [Bar Chart: Scores by month]                               │  ║
║ │  Shows scoring average trends                               │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 RECENT ROUNDS (Last 10)                                 │  ║
║ │                                                             │  ║
║ │  Date       Course            Score   Diff    Notes         │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Dec 23     Desert Ridge      82      10.5   League match   │  ║
║ │  Dec 16     Papago            88      13.2   Casual round   │  ║
║ │  Dec 9      Desert Ridge      79       8.9   Personal best  │  ║
║ │  Dec 2      Wildfire East     85      11.8   Tournament     │  ║
║ │  Nov 25     Desert Ridge      84      10.8   League match   │  ║
║ │  Nov 18     Troon North       91      14.5   Tough course   │  ║
║ │  Nov 11     Desert Ridge      83      10.2   League match   │  ║
║ │  Nov 4      Talking Stick     86      11.9   Casual round   │  ║
║ │  Oct 28     Desert Ridge      80       9.1   League match   │  ║
║ │  Oct 21     TPC Scottsdale    92      15.2   Pro course     │  ║
║ │                                                             │  ║
║ │  [View All Rounds (124)]                                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Leagues Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Activity] [Stats] [Leagues] [Achievements] [About]             ║
║                     ━━━━━━━━                                      ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  LEAGUE & TOURNAMENT HISTORY                                      ║
║                                                                   ║
║  Filter: [All] [Active] [Completed] | Sport: [All Sports ▼]      ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🟢 ACTIVE LEAGUES (3)                                      │  ║
║ │                                                             │  ║
║ │  🏌️ Monday Night Golf League                                │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Desert Ridge Golf Club                                     │  ║
║ │  Season: Spring 2025 • Week 8 of 12                         │  ║
║ │  Standing: 3rd of 32 players (Flight A)                     │  ║
║ │  Record: 6-2 in match play                                  │  ║
║ │  Avg Net: 72.3                                              │  ║
║ │  [View League Details]                                      │  ║
║ │                                                             │  ║
║ │  🔴 Weekend Pickleball Ladder                               │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Metro Pickleball Center                                    │  ║
║ │  Season: Winter 2025 • Week 6 of 12                         │  ║
║ │  Ranking: 7th of 24 players                                 │  ║
║ │  Record: 18-12 overall                                      │  ║
║ │  Win Rate: 60%                                              │  ║
║ │  [View League Details]                                      │  ║
║ │                                                             │  ║
║ │  🎳 Thursday Night Bowling                                  │  ║
║ │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │  ║
║ │  Sunset Lanes                                               │  ║
║ │  Season: Winter 2024-25 • Week 14 of 20                     │  ║
║ │  Team Standing: 2nd of 12 teams                             │  ║
║ │  Team: Strike Force                                         │  ║
║ │  Average: 182 (up from 178)                                 │  ║
║ │  [View League Details]                                      │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  ✅ COMPLETED LEAGUES (12)                                  │  ║
║ │                                                             │  ║
║ │  🏌️ Fall 2024 Golf League - Desert Ridge                    │  ║
║ │     🥇 1st Place (Flight A) • 10-2 record                   │  ║
║ │                                                             │  ║
║ │  🎳 Summer 2024 Bowling League - Sunset Lanes               │  ║
║ │     🥈 2nd Place (Team) • 178 avg                           │  ║
║ │                                                             │  ║
║ │  🏌️ Spring 2024 Golf League - Desert Ridge                  │  ║
║ │     4th Place (Flight B) • 8-4 record                       │  ║
║ │                                                             │  ║
║ │  🔴 Winter 2024 Pickleball Ladder - Metro PC                │  ║
║ │     5th Place • 24-16 record                                │  ║
║ │                                                             │  ║
║ │  [View All 12 Completed Leagues]                            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 TOURNAMENT HISTORY (8)                                  │  ║
║ │                                                             │  ║
║ │  Spring Championship 2024 - Desert Ridge                    │  ║
║ │  🥉 3rd Place • Team: The Birdies • -15 net                 │  ║
║ │  Prize: $800                                                │  ║
║ │                                                             │  ║
║ │  Fall Classic 2023 - Wildfire                               │  ║
║ │  7th Place • Team: Eagle Hunters • -12 net                  │  ║
║ │                                                             │  ║
║ │  Pickleball Open 2024 - Metro PC                            │  ║
║ │  Round of 16 • Doubles w/ Sarah Chen                        │  ║
║ │                                                             │  ║
║ │  [View All Tournaments]                                     │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Achievements Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Activity] [Stats] [Leagues] [Achievements] [About]             ║
║                               ━━━━━━━━━━━━━                       ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ACHIEVEMENTS & BADGES                                            ║
║                                                                   ║
║  542 Total XP • Level 12 • 28 Badges Earned • 15 In Progress      ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏆 FEATURED ACHIEVEMENTS                                   │  ║
║ │                                                             │  ║
║ │  ┌────────────────┬────────────────┬────────────────┐       │  ║
║ │  │ 🥇 League      │ 🎯 Eagle Eye   │ ⛳ Century     │       │  ║
║ │  │ Champion       │                 │ Club           │       │  ║
║ │  │ ━━━━━━━━━━━━━  │ ━━━━━━━━━━━━━  │ ━━━━━━━━━━━━━  │       │  ║
║ │  │ Won first     │ Made 3 eagles   │ Played 100     │       │  ║
║ │  │ place in a    │ in one round    │ rounds         │       │  ║
║ │  │ league        │                 │                │       │  ║
║ │  │               │ Earned:         │ Earned:        │       │  ║
║ │  │ Earned:       │ Dec 9, 2024     │ Nov 2024       │       │  ║
║ │  │ Fall 2024     │                 │                │       │  ║
║ │  └────────────────┴────────────────┴────────────────┘       │  ║
║ │                                                             │  ║
║ │  ┌────────────────┬────────────────┬────────────────┐       │  ║
║ │  │ 🔥 Hot Streak  │ 🎳 Turkey     │ 🔴 Pickleball  │       │  ║
║ │  │                 │                 │ Pro            │       │  ║
║ │  │ ━━━━━━━━━━━━━  │ ━━━━━━━━━━━━━  │ ━━━━━━━━━━━━━  │       │  ║
║ │  │ Won 5 matches │ Three strikes   │ Reached 4.0    │       │  ║
║ │  │ in a row      │ in a row       │ rating         │       │  ║
║ │  │               │                 │                │       │  ║
║ │  │ Current:      │ Earned:         │ In Progress:   │       │  ║
║ │  │ 5 wins        │ Oct 2024        │ 3.5/4.0        │       │  ║
║ │  └────────────────┴────────────────┴────────────────┘       │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  📊 PROGRESS TRACKER                                        │  ║
║ │                                                             │  ║
║ │  🎯 Near Completion (15)                                    │  ║
║ │                                                             │  ║
║ │  ⛳ Sub-Par Round                                            │  ║
║ │  Shoot under par (handicap-adjusted)                        │  ║
║ │  Progress: Best net 69 (need 71 or better)                  │  ║
║ │  ████████████████████░ 95%                                  │  ║
║ │                                                             │  ║
║ │  🏌️ 10 League Seasons                                       │  ║
║ │  Participate in 10 league seasons                           │  ║
║ │  Progress: 8/10 seasons                                     │  ║
║ │  ████████████████░░░░ 80%                                   │  ║
║ │                                                             │  ║
║ │  🥇 Tournament Podium                                       │  ║
║ │  Finish top 3 in a tournament                               │  ║
║ │  Progress: 3rd place once, need 1st or 2nd                  │  ║
║ │  ████████████████░░░░ 67%                                   │  ║
║ │                                                             │  ║
║ │  [View All Progress]                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  🏅 ALL ACHIEVEMENTS BY CATEGORY                            │  ║
║ │                                                             │  ║
║ │  Golf (12 earned, 8 in progress)                            │  ║
║ │  ✅ First Round                                             │  ║
║ │  ✅ 10 Rounds                                               │  ║
║ │  ✅ 50 Rounds                                               │  ║
║ │  ✅ Century Club (100 rounds)                               │  ║
║ │  ✅ Eagle Eye (3 eagles in one round)                       │  ║
║ │  ✅ Birdie Machine (10 birdies in 5 rounds)                 │  ║
║ │  ⏳ Sub-Par Round (95% complete)                            │  ║
║ │  ⏳ Breaking 80 (best: 79)                                  │  ║
║ │  🔒 Hole-in-One (locked)                                    │  ║
║ │  🔒 Course Record (locked)                                  │  ║
║ │                                                             │  ║
║ │  Pickleball (8 earned, 5 in progress)                       │  ║
║ │  ✅ First Match                                             │  ║
║ │  ✅ 25 Matches                                              │  ║
║ │  ✅ 50 Matches                                              │  ║
║ │  ✅ Rally Master (30+ shot rally)                           │  ║
║ │  ⏳ Pickleball Pro (3.5/4.0 rating)                         │  ║
║ │  ⏳ 100 Matches (87/100)                                    │  ║
║ │  🔒 Tournament Champion (locked)                            │  ║
║ │                                                             │  ║
║ │  Bowling (6 earned, 4 in progress)                          │  ║
║ │  ✅ First Game                                              │  ║
║ │  ✅ 100 Games                                               │  ║
║ │  ✅ Turkey (3 strikes in a row)                             │  ║
║ │  ⏳ 200 Club (high game 257/300)                            │  ║
║ │  ⏳ 250 Club (high game 257/300)                            │  ║
║ │  🔒 Perfect Game (locked)                                   │  ║
║ │                                                             │  ║
║ │  Platform (2 earned, 3 in progress)                         │  ║
║ │  ✅ Multi-Sport Athlete (3+ sports)                         │  ║
║ │  ✅ Social Butterfly (100+ followers)                       │  ║
║ │  ⏳ League Legend (8/10 seasons)                            │  ║
║ │  🔒 Triple Champion (locked)                                │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## About Tab

```
╔═══════════════════════════════════════════════════════════════════╗
║  [Activity] [Stats] [Leagues] [Achievements] [About]             ║
║                                              ━━━━━                ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  ABOUT ALEX                                                       ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  BIO                                                        │  ║
║ │                                                             │  ║
║ │  Weekend warrior golfer with a passion for competitive     │  ║
║ │  play. Started playing golf 5 years ago and haven't looked │  ║
║ │  back since. Recently got into pickleball and loving the   │  ║
║ │  fast-paced action. Also bowl in a Thursday night league   │  ║
║ │  with friends.                                              │  ║
║ │                                                             │  ║
║ │  Always looking for new leagues and playing partners.       │  ║
║ │  Feel free to reach out if you want to play a round!        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  BASIC INFORMATION                                          │  ║
║ │                                                             │  ║
║ │  📍 Location: Phoenix, AZ                                   │  ║
║ │  📅 Member since: January 2022 (3 years)                    │  ║
║ │  🎂 Age: [Hidden - Privacy Setting]                         │  ║
║ │  👤 Gender: Male                                            │  ║
║ │  🗣️ Languages: English, Spanish                            │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  SPORTS & SKILL LEVELS                                      │  ║
║ │                                                             │  ║
║ │  🏌️ Golf                                                     │  ║
║ │     Handicap: 8.2                                           │  ║
║ │     Playing Since: 2020                                     │  ║
║ │     Preferred Format: Stroke play, Scrambles                │  ║
║ │     Favorite Courses: Desert Ridge, Troon North             │  ║
║ │                                                             │  ║
║ │  🔴 Pickleball                                              │  ║
║ │     Rating: 3.5                                             │  ║
║ │     Playing Since: 2023                                     │  ║
║ │     Position: All positions                                 │  ║
║ │     Preferred Format: Doubles                               │  ║
║ │                                                             │  ║
║ │  🎳 Bowling                                                 │  ║
║ │     Average: 178                                            │  ║
║ │     Playing Since: 2021                                     │  ║
║ │     Style: Stroker                                          │  ║
║ │     Favorite Center: Sunset Lanes                           │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  AVAILABILITY                                               │  ║
║ │                                                             │  ║
║ │  Typical play times:                                        │  ║
║ │  • Weekday evenings (after 5 PM)                           │  ║
║ │  • Weekend mornings (7 AM - 12 PM)                         │  ║
║ │                                                             │  ║
║ │  Preferred days:                                            │  ║
║ │  Monday, Wednesday, Saturday, Sunday                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  INTERESTS & GOALS                                          │  ║
║ │                                                             │  ║
║ │  Goals:                                                     │  ║
║ │  • Get handicap to single digits (currently 8.2)           │  ║
║ │  • Win a tournament                                         │  ║
║ │  • Reach 4.0 pickleball rating                             │  ║
║ │  • Bowl a 200+ average                                      │  ║
║ │                                                             │  ║
║ │  Looking for:                                               │  ║
║ │  • Competitive leagues                                      │  ║
║ │  • Tournament partners                                      │  ║
║ │  • Practice rounds                                          │  ║
║ │  • New sports to try                                        │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  CONNECTIONS                                                │  ║
║ │                                                             │  ║
║ │  👥 234 followers • 189 following                           │  ║
║ │                                                             │  ║
║ │  Mutual Connections (12)                                    │  ║
║ │  [Avatar] Sarah Chen                                        │  ║
║ │  [Avatar] Mike Thompson                                     │  ║
║ │  [Avatar] David Park                                        │  ║
║ │  ... and 9 more                                             │  ║
║ │                                                             │  ║
║ │  [View All Followers] [View All Following]                  │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
║ ┌─────────────────────────────────────────────────────────────┐  ║
║ │  JOINED COMMUNITIES                                         │  ║
║ │                                                             │  ║
║ │  🏌️ Phoenix Golf League Players (1,234 members)            │  ║
║ │  🔴 Arizona Pickleball Community (2,891 members)            │  ║
║ │  🎳 Valley Bowlers Network (567 members)                    │  ║
║ └─────────────────────────────────────────────────────────────┘  ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## User State Variations

### Anonymous Visitor (Limited View)
```
Profile shows:
- Basic public info (name, location, bio)
- Public stats only
- Active leagues (limited details)
- Achievements (if set to public)

Hidden:
- Contact information
- Full activity feed
- Detailed stats
- Personal connections

Action prompts:
"Sign in to message Alex"
"Create an account to follow"
```

### Logged-In User Viewing Someone Else
```
Additional features available:
- Follow/Unfollow button
- Message button
- Share profile
- View mutual connections
- See shared leagues

Privacy respected:
- Only shows what player has set to public
- No access to private leagues/stats
```

### Profile Owner Viewing Own Profile
```
Additional controls:
┌─────────────────────────────────────────────────────────────┐
│  [Edit Profile] [Privacy Settings] [View as Public]        │
└─────────────────────────────────────────────────────────────┘

Can see:
- All activity (public + private)
- Complete stats
- Edit bio and preferences
- Manage privacy settings
- Delete content
```

---

## Privacy Settings Modal

```
╔═══════════════════════════════════════════════════════════════════╗
║  PRIVACY SETTINGS                                                 ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Control what others can see on your profile                      ║
║                                                                   ║
║  Profile Visibility                                               ║
║  ⚪ Public - Anyone can view                                      ║
║  ⚪ Friends Only - Only people you follow                         ║
║  ⚪ Private - Only you                                            ║
║                                                                   ║
║  Statistics Visibility                                            ║
║  ☑ Show golf stats                                                ║
║  ☑ Show pickleball stats                                          ║
║  ☑ Show bowling stats                                             ║
║  ☑ Show achievements                                              ║
║  ☐ Show detailed round history                                    ║
║                                                                   ║
║  League History                                                   ║
║  ☑ Show active leagues                                            ║
║  ☑ Show completed leagues                                         ║
║  ☐ Show league standings                                          ║
║  ☑ Show tournament results                                        ║
║                                                                   ║
║  Activity Feed                                                    ║
║  ☑ Show recent activity                                           ║
║  ☐ Show photos                                                    ║
║  ☑ Show achievements                                              ║
║                                                                   ║
║  Contact & Social                                                 ║
║  ⚪ Anyone can message me                                         ║
║  ⚪ Only people I follow can message me                           ║
║  ⚪ No one can message me                                         ║
║                                                                   ║
║  ☑ Show follower count                                            ║
║  ☑ Show following count                                           ║
║  ☐ Show mutual connections                                        ║
║                                                                   ║
║  Personal Information                                             ║
║  ☑ Show location (city level)                                     ║
║  ☐ Show age                                                       ║
║  ☐ Show email address                                             ║
║  ☐ Show phone number                                              ║
║                                                                   ║
║  [Save Settings] [Cancel]                                         ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

## Mobile Optimization

### Mobile Profile Header (Stacked)
```
┌───────────────────────────────┐
│ [Cover Photo]                 │
│                               │
│ [Avatar]                      │
│ Alex Martinez                 │
│ @alexm • Phoenix, AZ          │
│                               │
│ [Follow] [Message] [Share]    │
│                               │
│ Bio text here...              │
│                               │
│ ┌─────┬─────┬─────┬─────┐    │
│ │ Lvl │ XP  │ Fol │ Win │    │
│ │ 12  │ 542 │ 234 │ 68% │    │
│ └─────┴─────┴─────┴─────┘    │
└───────────────────────────────┘
```

### Mobile Tabs (Horizontal Scroll)
```
┌─────────────────────────────────────┐
│ [Activity] [Stats] [Leagues] [More]→│
└─────────────────────────────────────┘
```

---

## API Integration Points

**GET `/players/{id}` or `/users/{id}`**
- Fetch player profile
- Respect privacy settings
- Return appropriate data based on viewer relationship

**GET `/players/{id}/stats`**
- Fetch sport-specific statistics
- Filter by time period
- Return achievement progress

**GET `/players/{id}/leagues`**
- Fetch league participation history
- Filter by status (active, completed)
- Include tournament history

**GET `/players/{id}/activity`**
- Fetch recent activity feed
- Paginated results
- Filter by activity type

**GET `/players/{id}/achievements`**
- Fetch all achievements
- Include progress on incomplete ones
- Group by category

**POST `/players/{id}/follow`**
- Follow/unfollow player
- Update follower count
- Trigger notification

**POST `/players/{id}/message`**
- Send message to player
- Check privacy settings
- Create conversation thread

**PUT `/players/{id}/privacy`**
- Update privacy settings
- Owner only
- Validate settings

---

## SEO & Metadata

**Title:**
`{Player Name} (@{username}) - {Sport} Player | The League`

**Description:**
`View {Player Name}'s profile on The League. {Sports played} • {Level} • {XP} XP • {Leagues count} leagues`

**Structured Data (JSON-LD):**
```json
{
  "@type": "Person",
  "name": "Alex Martinez",
  "description": "Golf, Pickleball, Bowling player",
  "sameAs": ["https://theleague.com/players/alex-martinez"],
  "sport": ["Golf", "Pickleball", "Bowling"]
}
```

---

Perfect! Now let me present all the wireframes and create the final piece: **Payment Pages**...

